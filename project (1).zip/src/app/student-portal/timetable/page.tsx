
"use client";

import { useEffect, useState, useMemo, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent 
} from '@/components/ui/card';
import { Printer, Calendar, MapPin, Loader2, ArrowLeft, Clock } from 'lucide-react';
import { 
  useFirestore, 
  useCollection,
  useMemoFirebase
} from '@/firebase';
import { collection, query, where } from 'firebase/firestore';
import { cn } from '@/lib/utils';

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const TIME_SLOTS = Array.from({ length: 29 }, (_, i) => {
  const totalMinutes = 7 * 60 + i * 30;
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
});

const formatTo12Hour = (time24: string) => {
  if (!time24) return '';
  const [hour, minute] = time24.split(':');
  const h = parseInt(hour);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${minute} ${ampm}`;
};

const isTimeInClass = (slot: string, startTime: string, endTime: string) => {
  return slot >= startTime && slot < endTime;
};

const calculateBoxHeight = (startTime: string, endTime: string) => {
  const [sH, sM] = startTime.split(':').map(Number);
  const [eH, eM] = endTime.split(':').map(Number);
  const durationInMinutes = (eH * 60 + eM) - (sH * 60 + sM);
  const slots = durationInMinutes / 30;
  return slots * 50 - 4; 
};

function TimetableView() {
  const searchParams = useSearchParams();
  const db = useFirestore();
  
  const profId = searchParams.get('prof');
  const studentId = searchParams.get('sid');

  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const schedulesRef = useMemoFirebase(() => collection(db, 'schedules'), [db]);
  const { data: allSchedules, isLoading: isSchedLoading } = useCollection(schedulesRef);

  const enrollmentsQuery = useMemoFirebase(() => {
    if (!studentId) return null;
    return query(collection(db, 'enrollments'), where('studentId', '==', studentId.trim()));
  }, [db, studentId]);
  const { data: enrollments, isLoading: isEnrolLoading } = useCollection(enrollmentsQuery);

  const enrolledSchedules = useMemo(() => {
    if (!enrollments || !allSchedules) return [];
    const scheduleIds = enrollments.map((e: any) => e.scheduleId);
    return allSchedules.filter((s: any) => scheduleIds.includes(s.id));
  }, [enrollments, allSchedules]);

  if (!isClient || isSchedLoading || isEnrolLoading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  const queryParams = `?prof=${profId}&sid=${studentId}`;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center no-print">
        <div className="flex items-center gap-4">
          <Link href={`/student-portal/prospectus${queryParams}`}>
            <Button variant="outline" size="icon" className="h-9 w-9 rounded-full border-neutral-300 bg-white shadow-sm">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h2 className="text-2xl font-black uppercase tracking-tight text-secondary">Weekly Timetable</h2>
        </div>
        <Button variant="outline" className="bg-white rounded-xl font-black text-[10px] uppercase tracking-widest h-10 shadow-sm border-neutral-300" onClick={() => window.print()}>
          <Printer className="h-3.5 w-3.5 mr-2" /> Print PDF
        </Button>
      </div>

      <Card className="rounded-3xl shadow-xl overflow-hidden bg-white border-none">
        <CardHeader className="bg-neutral-900 text-white p-8">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl font-black uppercase tracking-tight">Academic Schedule</CardTitle>
              <CardDescription className="text-neutral-400 font-bold uppercase tracking-widest mt-1 italic">Official 12-Hour Weekly View</CardDescription>
            </div>
            <div className="bg-white/10 px-4 py-2 rounded-xl backdrop-blur-sm">
               <span className="text-[10px] font-black uppercase tracking-widest">{enrolledSchedules.length} Subjects Enrolled</span>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-4 md:p-6 overflow-x-auto">
          <div className="min-w-[900px]">
            <div className="grid grid-cols-7 border-b-2 border-neutral-200 bg-neutral-50 sticky top-0 z-20">
              <div className="p-4 border-r text-[9px] font-black uppercase tracking-widest text-muted-foreground flex items-center justify-center">
                <Clock className="h-3.5 w-3.5 mr-1" /> Time
              </div>
              {DAYS.map(day => (
                <div key={day} className="p-4 text-center font-black uppercase text-[10px] tracking-widest text-secondary border-r last:border-0">{day}</div>
              ))}
            </div>

            <div className="relative">
              {TIME_SLOTS.map((slot) => (
                <div key={slot} className="grid grid-cols-7 border-b border-neutral-100 min-h-[50px]">
                  <div className="p-2 border-r bg-neutral-50/50 flex flex-col items-center justify-center">
                    <span className="text-[9px] font-mono font-black text-secondary/60">{formatTo12Hour(slot)}</span>
                  </div>
                  {DAYS.map(day => {
                    const subjectAtStart = enrolledSchedules.find(s => s.day === day && s.startTime === slot);
                    const isOccupied = enrolledSchedules.some(s => s.day === day && isTimeInClass(slot, s.startTime, s.endTime));

                    return (
                      <div key={`${day}-${slot}`} className={cn("p-0.5 border-r last:border-0 relative", isOccupied ? "bg-primary/5" : "")}>
                        {subjectAtStart && (
                          <div 
                            className="absolute inset-x-1 top-1 bg-secondary text-white p-2.5 rounded-2xl shadow-xl z-10 overflow-hidden flex flex-col justify-start border-l-4 border-primary"
                            style={{ 
                              height: `${calculateBoxHeight(subjectAtStart.startTime, subjectAtStart.endTime)}px`,
                              zIndex: 10
                            }}
                          >
                            <div className="flex flex-col gap-0.5">
                              <span className="text-[10px] font-black leading-none uppercase truncate">{subjectAtStart.subjectCode}</span>
                              <span className="text-[8px] font-bold opacity-90 uppercase tracking-tight line-clamp-1">{subjectAtStart.subjectName}</span>
                            </div>
                            <div className="mt-auto space-y-0.5 pt-1 border-t border-white/20">
                              <div className="flex items-center gap-1 opacity-90">
                                <Clock className="h-2.5 w-2.5" />
                                <span className="text-[7px] font-black uppercase whitespace-nowrap">
                                  {formatTo12Hour(subjectAtStart.startTime)} - {formatTo12Hour(subjectAtStart.endTime)}
                                </span>
                              </div>
                              <div className="flex items-center gap-1 opacity-90">
                                <MapPin className="h-2.5 w-2.5" />
                                <span className="text-[7px] font-black uppercase truncate">{subjectAtStart.room}</span>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function StudentTimetablePage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>}>
      <TimetableView />
    </Suspense>
  );
}
