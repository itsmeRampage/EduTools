# FREE Deployment Guide (No Credit Card Required)

Follow these steps to host your **EDUProfile** system for free on Vercel.

## 1. Prepare your GitHub Repository
1. Open your repository: [https://github.com/itsmeRampage/EduTools](https://github.com/itsmeRampage/EduTools).
2. **IMPORTANT**: If your repository is empty, follow the `docs/GITHUB_GUIDE.md` to upload your files first. Vercel will say "Not Found" if the repository has no code.

## 2. Deploy to Vercel (Free)
1. Go to [Vercel](https://vercel.com/signup) and sign up using your **GitHub** account.
2. Click **"Add New..."** and then **"Project"**.
3. Find your `EduTools` repository in the list and click **"Import"**.
4. **Environment Variables (CRITICAL - FIXES "NOT FOUND" ERRORS)**:
   - Expand the **"Environment Variables"** section before clicking Deploy.
   - Add these keys exactly as they appear in your `src/firebase/config.ts`:
     - `NEXT_PUBLIC_FIREBASE_API_KEY`: (Copy from your config)
     - `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`: (Copy from your config)
     - `NEXT_PUBLIC_FIREBASE_PROJECT_ID`: `studio-4144227073-47fa3`
     - `NEXT_PUBLIC_FIREBASE_APP_ID`: (Copy from your config)
5. Click **"Deploy"**.

## 3. Why am I getting a 404 / Not Found?
- **Check GitHub**: Go to your repository and make sure you see folders like `src`, `public`, and files like `package.json`. If you only see a README, you haven't uploaded your code yet.
- **Check Build Logs**: In Vercel, click on your project and look at "Deployments". If it failed, it will tell you why. Usually, it is because of a missing Environment Variable (Step 4 above).

## 4. Student Access Recovery
- If a student forgets their Access Key, go to the Student Portal Login and click "Forgot Key".
- Entering their **Student ID** will reset their password to be their **Student ID** again.
- Once they log in, they can go to the bottom of their Prospectus to set a new private password.