"use client";

import { useEffect, useState, useRef, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { 
  Printer, 
  Save, 
  Camera, 
  Loader2, 
  ArrowLeft,
  GraduationCap,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck
} from 'lucide-react';
import { 
  useFirestore, 
  useDoc, 
  useMemoFirebase,
  updateDocumentNonBlocking
} from '@/firebase';
import { doc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

function ProspectusView() {
  const searchParams = useSearchParams();
  const db = useFirestore();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const profId = searchParams.get('prof');
  const studentId = searchParams.get('sid');

  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [isUpdatingPass, setIsUpdatingPass] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [newPass, setNewPass] = useState("");

  const [localStudentInfo, setLocalStudentInfo] = useState({ 
    name: "", 
    permanentAddress: "", 
    phone: "", 
    id: "" 
  });
  const [localPhotoUrl, setLocalPhotoUrl] = useState("");

  const studentDocRef = useMemoFirebase(() => {
    if (!profId || !studentId) return null;
    return doc(db, 'professors', profId, 'students', studentId.trim());
  }, [db, profId, studentId]);
  
  const { data: record, isLoading } = useDoc(studentDocRef);

  useEffect(() => {
    if (record && record.prospectusData) {
      setLocalStudentInfo({
        name: record.prospectusData.studentInfo?.name || "",
        permanentAddress: record.prospectusData.studentInfo?.permanentAddress || "",
        phone: record.prospectusData.studentInfo?.phone || "",
        id: studentId || ""
      });
      setLocalPhotoUrl(record.photoUrl || "");
    }
  }, [record, studentId]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLocalPhotoUrl(reader.result as string);
        toast({ title: "Photo Updated", description: "Click Save Profile to finalize your 2x2 ID photo." });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = async () => {
    if (!profId || !studentId || !record) return;
    setIsSavingProfile(true);

    const profStudentRef = doc(db, 'professors', profId, 'students', studentId);
    const globalRef = doc(db, 'students', studentId);

    const updatedProspectus = {
      ...record.prospectusData,
      studentInfo: {
        ...record.prospectusData.studentInfo,
        name: localStudentInfo.name,
        permanentAddress: localStudentInfo.permanentAddress,
        phone: localStudentInfo.phone
      }
    };

    const payload = {
      prospectusData: updatedProspectus,
      photoUrl: localPhotoUrl,
      lastUpdated: new Date().toISOString()
    };

    updateDocumentNonBlocking(profStudentRef, payload);
    updateDocumentNonBlocking(globalRef, { photoUrl: localPhotoUrl });

    toast({ title: "Profile Saved", description: "Personal details and ID photo updated." });
    setTimeout(() => setIsSavingProfile(false), 800);
  };

  const handleUpdatePassword = async () => {
    if (!profId || !studentId || !newPass.trim()) return;
    setIsUpdatingPass(true);

    const payload = {
      portalPassword: newPass.trim(),
      lastSecurityUpdate: new Date().toISOString()
    };

    updateDocumentNonBlocking(doc(db, 'professors', profId, 'students', studentId), payload);
    updateDocumentNonBlocking(doc(db, 'students', studentId), payload);

    toast({ title: "Key Updated", description: "Your unique access key is now active." });
    setNewPass("");
    setIsUpdatingPass(false);
  };

  const calculateGWA = (courses: any[]) => {
    if (!courses || courses.length === 0) return '---';
    let totalQualityPoints = 0;
    let totalUnits = 0;
    courses.forEach(c => {
      const grade = parseFloat(c.gradeRating);
      const units = parseFloat(c.totalCreditUnits);
      if (!isNaN(grade) && grade > 0 && !isNaN(units)) {
        totalQualityPoints += (grade * units);
        totalUnits += units;
      }
    });
    return totalUnits === 0 ? '---' : (totalQualityPoints / totalUnits).toFixed(2);
  };

  if (isLoading) return <div className="flex justify-center py-20"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>;
  if (!record) return null;

  return (
    <div className="space-y-6">
      <div className="no-print flex items-center justify-between mb-4 sticky top-4 z-20 px-2 md:px-0">
        <div className="flex items-center gap-2">
          <Link href="/">
            <Button variant="outline" size="icon" className="h-8 w-8 rounded-full border-neutral-300 bg-white">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <span className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Academic Records Gateway</span>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" className="h-8 text-[9px] font-black tracking-widest bg-white border border-neutral-300 shadow-sm" onClick={() => window.print()}>
            <Printer className="h-3.5 w-3.5 mr-1.5" /> PRINT
          </Button>
          <Button size="sm" className="h-8 text-[9px] font-black tracking-widest bg-primary shadow-lg" onClick={handleSaveProfile} disabled={isSavingProfile}>
            {isSavingProfile ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Save className="h-3.5 w-3.5 mr-1.5" />}
            SAVE PROFILE
          </Button>
        </div>
      </div>

      <div className="bg-white border border-neutral-300 shadow-2xl p-8 md:p-12 print:p-0 print:border-none print:shadow-none min-h-[1100px] text-black font-serif text-[11px] leading-tight mx-auto max-w-[950px]">
        
        <div className="relative flex flex-col items-center mb-10">
          <div className="text-center space-y-1 w-full max-w-[600px]">
            <p className="text-[10px] uppercase font-medium">{record.headerData?.republic || "Republic of the Philippines"}</p>
            <p className="text-[18px] font-black uppercase tracking-widest text-neutral-900 leading-none">{record.headerData?.university || "UNIVERSITY PORTAL"}</p>
            <p className="text-[11px] font-medium opacity-70">{record.headerData?.location || "Academic Records Division"}</p>
            <div className="h-px w-32 bg-black mx-auto my-3" />
            <p className="text-[12px] uppercase font-bold">{record.headerData?.college || "College Department"}</p>
          </div>
          
          <div 
            className="absolute right-0 top-0 border-[2px] border-black w-28 h-28 flex items-center justify-center bg-neutral-50 cursor-pointer overflow-hidden no-print"
            onClick={() => fileInputRef.current?.click()}
          >
            {localPhotoUrl ? (
              <img src={localPhotoUrl} alt="2x2" className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center">
                <Camera className="h-6 w-6 text-neutral-300" />
                <span className="text-[8px] font-black mt-1">2x2 PHOTO</span>
              </div>
            )}
            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
          </div>
          <div className="hidden print:block absolute right-0 top-0 border-[2px] border-black w-28 h-28 overflow-hidden">
             {localPhotoUrl ? <img src={localPhotoUrl} alt="ID" className="w-full h-full object-cover" /> : null}
          </div>
        </div>

        <div className="grid grid-cols-12 gap-x-6 gap-y-3 mt-8 mb-10 border-t-2 border-black pt-6">
          <div className="col-span-8 flex border-b border-black pb-1">
            <span className="font-bold min-w-[50px] text-[10px] uppercase">Name:</span>
            <input className="flex-1 px-2 uppercase font-bold text-[13px] bg-transparent outline-none border-none" value={localStudentInfo.name} onChange={(e) => setLocalStudentInfo({...localStudentInfo, name: e.target.value})} />
          </div>
          <div className="col-span-4 flex border-b border-black pb-1">
            <span className="font-bold min-w-[90px] text-[10px] uppercase">ID No.:</span>
            <span className="flex-1 px-2 font-mono font-bold">{localStudentInfo.id}</span>
          </div>
          <div className="col-span-8 flex border-b border-black pb-1">
            <span className="font-bold min-w-[100px] text-[10px] uppercase">Address:</span>
            <input className="flex-1 px-2 font-medium bg-transparent outline-none border-none" value={localStudentInfo.permanentAddress} onChange={(e) => setLocalStudentInfo({...localStudentInfo, permanentAddress: e.target.value})} />
          </div>
          <div className="col-span-4 flex border-b border-black pb-1">
            <span className="font-bold min-w-[90px] text-[10px] uppercase">Phone:</span>
            <input className="flex-1 px-2 font-medium bg-transparent outline-none border-none" value={localStudentInfo.phone} onChange={(e) => setLocalStudentInfo({...localStudentInfo, phone: e.target.value})} />
          </div>
        </div>

        {record.prospectusData.academicProspectus?.map((year: any) => (
          <div key={year.name} className="mb-10 break-inside-avoid">
            <div className="bg-neutral-900 text-white py-1.5 text-center border border-black mb-1 font-bold text-[13px] uppercase tracking-[0.4em]">
              {year.name}
            </div>
            {year.semesters?.map((sem: any) => (
              <div key={sem.name} className="mb-8">
                <div className="text-center py-1.5 font-bold uppercase text-[11px] bg-neutral-100 border border-black mb-1 italic tracking-widest">
                  {sem.name}
                </div>
                <table className="w-full border-collapse border border-black table-fixed text-[10px]">
                  <thead>
                    <tr className="bg-neutral-50 font-bold uppercase text-[8px]">
                      <th className="border border-black p-1 w-[10%]">Rating</th>
                      <th className="border border-black p-1 w-[15%]">Code</th>
                      <th className="border border-black p-1 text-left w-[40%]">Course Description</th>
                      <th className="border border-black p-1 w-[10%]">Units</th>
                      <th className="border border-black p-1 w-[25%]">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sem.courses?.map((c: any, idx: number) => (
                      <tr key={idx} className="h-7">
                        <td className="border border-black text-center font-bold text-[12px]">{c.gradeRating || '---'}</td>
                        <td className="border border-black text-center font-bold">{c.courseCode}</td>
                        <td className="border border-black px-2 truncate">{c.courseDescription}</td>
                        <td className="border border-black text-center font-bold">{c.totalCreditUnits}</td>
                        <td className="border border-black text-center">
                          {parseFloat(c.gradeRating) <= 3.0 ? <span className="text-blue-700 font-black text-[9px] uppercase">Passed</span> : <span className="text-neutral-400 font-bold text-[8px] uppercase">Pending</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="flex justify-between items-center mt-2 px-2">
                  <p className="font-bold">GWA: <span className="text-[12px] ml-1">{calculateGWA(sem.courses)}</span></p>
                  <p className="text-[8px] uppercase font-bold text-neutral-400 italic">Official Digital Record</p>
                </div>
              </div>
            ))}
          </div>
        ))}

        <div className="mt-12 pt-8 border-t border-dashed border-neutral-300 no-print">
          <div className="max-w-[400px] mx-auto bg-neutral-50 p-6 rounded-3xl border border-neutral-200 shadow-sm">
            <div className="flex items-center gap-2 mb-4">
              <Lock className="h-4 w-4 text-primary" />
              <h4 className="text-[11px] font-black uppercase tracking-widest">Update Access Key</h4>
            </div>
            <div className="space-y-4">
              <div className="space-y-1">
                <Label className="text-[9px] font-black uppercase text-neutral-500">New Password</Label>
                <div className="relative">
                  <Input 
                    type={showPass ? "text" : "password"} 
                    className="h-11 rounded-xl text-xs"
                    value={newPass}
                    onChange={(e) => setNewPass(e.target.value)}
                  />
                  <button className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400" onClick={() => setShowPass(!showPass)}>
                    {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <Button 
                className="w-full h-11 rounded-xl font-black text-[10px] uppercase tracking-widest bg-secondary" 
                onClick={handleUpdatePassword}
                disabled={isUpdatingPass || !newPass.trim()}
              >
                {isUpdatingPass ? <Loader2 className="h-3 w-3 animate-spin mr-2" /> : null}
                Finalize New Key
              </Button>
            </div>
          </div>
        </div>

        <div className="mt-16 text-center text-[9px] text-neutral-400 italic">
          Disclaimer: Unauthorized modifications to official academic evaluations are strictly prohibited.
        </div>
      </div>
    </div>
  );
}

export default function StudentProspectusPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>}>
      <ProspectusView />
    </Suspense>
  );
}