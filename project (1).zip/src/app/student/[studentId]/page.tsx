
"use client";

import { useState, use, useEffect, useMemo, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { 
  ArrowLeft, 
  Printer, 
  Save,
  Plus,
  Trash2,
  GraduationCap,
  Share2,
  Check,
  Loader2,
  Camera,
  User
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { automatedProspectusCreation } from '@/ai/flows/automated-prospectus-creation';
import { type AutomatedProspectusCreationOutput } from '@/ai/schemas/prospectus';
import { 
  useUser, 
  useFirestore, 
  useDoc, 
  useMemoFirebase, 
  setDocumentNonBlocking 
} from '@/firebase';
import { doc } from 'firebase/firestore';
import Image from 'next/image';

export default function StudentProspectus({ params }: { params: Promise<{ studentId: string }> }) {
  const { studentId } = use(params);
  const { user, isUserLoading } = useUser();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [prospectusData, setProspectusData] = useState<AutomatedProspectusCreationOutput | null>(null);
  const [photoUrl, setPhotoUrl] = useState<string>("");

  const [headerData, setHeaderData] = useState({
    republic: "Republic of the Philippines",
    university: "UNIVERSITY PORTAL",
    location: "Academic Records Division",
    college: "College Department",
    degree: "Degree Program Title",
    basis: "Official Prospectus Evaluation"
  });

  // Guarded auth check
  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/auth/login');
    }
  }, [user, isUserLoading, router]);

  // Load existing data from Firestore
  const studentDocRef = useMemoFirebase(() => {
    if (!user) return null;
    return doc(db, 'professors', user.uid, 'students', studentId.trim());
  }, [db, user, studentId]);

  const { data: studentRecord, isLoading: isDocLoading } = useDoc(studentDocRef);

  useEffect(() => {
    if (isDocLoading) return;

    if (studentRecord) {
      if (studentRecord.prospectusData) {
        setProspectusData(studentRecord.prospectusData);
      }
      if (studentRecord.headerData) {
        setHeaderData(studentRecord.headerData);
      }
      if (studentRecord.photoUrl) {
        setPhotoUrl(studentRecord.photoUrl);
      }
      setLoading(false);
    }
  }, [studentRecord, isDocLoading]);

  // Image upload handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setPhotoUrl(base64String);
        toast({
          title: "Photo Prepared",
          description: "Click Save Record to persist this 2x2 ID photo.",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFieldChange = (yearIdx: number, semIdx: number, courseIdx: number, field: string, value: string | number) => {
    if (!prospectusData) return;
    const newProspectus = JSON.parse(JSON.stringify(prospectusData.academicProspectus));
    newProspectus[yearIdx].semesters[semIdx].courses[courseIdx][field] = value;
    setProspectusData({ ...prospectusData, academicProspectus: newProspectus });
  };

  const handleSemesterFieldChange = (yearIdx: number, semIdx: number, field: string, value: string) => {
    if (!prospectusData) return;
    const newProspectus = JSON.parse(JSON.stringify(prospectusData.academicProspectus));
    newProspectus[yearIdx].semesters[semIdx][field] = value;
    setProspectusData({ ...prospectusData, academicProspectus: newProspectus });
  };

  const handleStudentInfoChange = (field: string, value: string) => {
    if (!prospectusData) return;
    setProspectusData({
      ...prospectusData,
      studentInfo: { ...prospectusData.studentInfo, [field]: value }
    });
  };

  const handleAddCourse = (yearIdx: number, semIdx: number) => {
    if (!prospectusData) return;
    const newProspectus = JSON.parse(JSON.stringify(prospectusData.academicProspectus));
    newProspectus[yearIdx].semesters[semIdx].courses.push({
      yrSemTaken: "", courseCode: "", universityCode: "", courseDescription: "",
      lectureHours: 0, labHours: 0, totalCreditUnits: 0, prerequisite: "", gradeRating: ""
    });
    setProspectusData({ ...prospectusData, academicProspectus: newProspectus });
  };

  const handleRemoveCourse = (yearIdx: number, semIdx: number, courseIdx: number) => {
    if (!prospectusData) return;
    const newProspectus = JSON.parse(JSON.stringify(prospectusData.academicProspectus));
    newProspectus[yearIdx].semesters[semIdx].courses.splice(courseIdx, 1);
    setProspectusData({ ...prospectusData, academicProspectus: newProspectus });
  };

  const calculateGWA = (courses: any[]) => {
    if (!courses || courses.length === 0) return '---';
    let totalQualityPoints = 0;
    let totalUnits = 0;
    courses.forEach(c => {
      const grade = parseFloat(c.gradeRating);
      const units = parseFloat(c.totalCreditUnits);
      if (!isNaN(grade) && grade > 0 && !isNaN(units)) {
        totalQualityPoints += (grade * units);
        totalUnits += units;
      }
    });
    return totalUnits === 0 ? '---' : (totalQualityPoints / totalUnits).toFixed(2);
  };

  const handleSave = () => {
    if (!user || !prospectusData) return;
    setIsSaving(true);
    
    const trimmedId = studentId.trim();
    const ref = doc(db, 'professors', user.uid, 'students', trimmedId);
    const globalRef = doc(db, 'students', trimmedId);
    
    const updateData = {
      prospectusData,
      headerData,
      photoUrl,
      lastUpdated: new Date().toISOString(),
      id: trimmedId,
      firstName: studentRecord?.firstName || prospectusData.studentInfo.name.split(',')[1]?.trim() || '',
      lastName: studentRecord?.lastName || prospectusData.studentInfo.name.split(',')[0]?.trim() || '',
      programId: studentRecord?.programId || 'active'
    };

    // Save to professor workspace
    setDocumentNonBlocking(ref, updateData, { merge: true });

    // Ensure global registry is in sync for Student Portal access
    setDocumentNonBlocking(globalRef, {
      id: trimmedId,
      managingProfessorId: user.uid,
      firstName: updateData.firstName,
      lastName: updateData.lastName,
      photoUrl,
      lastSynced: new Date().toISOString()
    }, { merge: true });
    
    toast({ 
      title: "Records Saved", 
      description: "Student profile and global login registry updated successfully." 
    });
    
    setTimeout(() => setIsSaving(false), 500);
  };

  const handleShare = () => {
    if (!user) return;
    // Shared public link to the evaluation view
    const shareUrl = `${window.location.origin}/view/${user.uid}/${studentId.trim()}`;
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    toast({ 
      title: "Public Link Copied", 
      description: "Share this direct URL for viewing the evaluation without login. It does not expire." 
    });
    setTimeout(() => setCopied(false), 3000);
  };

  if (isUserLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center">
          <Loader2 className="h-10 w-10 animate-spin text-primary mb-4" />
          <p className="text-muted-foreground font-bold uppercase tracking-widest text-[10px]">Syncing Evaluation...</p>
        </div>
      </div>
    );
  }

  if (!user || !prospectusData) return null;

  return (
    <div className="min-h-screen bg-neutral-100 p-0 md:p-8">
      <div className="no-print max-w-[1000px] mx-auto flex items-center justify-between mb-4 px-4 md:px-0 sticky top-4 z-20">
        <div className="flex items-center gap-2">
          <Link href={`/course/${studentRecord?.programId || 'active'}`}>
            <Button variant="outline" size="icon" className="h-8 w-8 rounded-full border-neutral-300 bg-white shadow-sm">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="flex items-center gap-2">
            <GraduationCap className="h-5 w-5 text-primary" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-neutral-500">Instructor Evaluation Panel</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="h-8 text-[10px] font-bold tracking-tight bg-white border-neutral-300 shadow-sm uppercase tracking-widest" onClick={handleShare}>
            {copied ? <Check className="h-3.5 w-3.5 mr-1.5 text-green-600" /> : <Share2 className="h-3.5 w-3.5 mr-1.5" />}
            {copied ? 'LINK COPIED' : 'COPY PUBLIC LINK'}
          </Button>
          <Button variant="secondary" size="sm" className="h-8 text-[10px] font-bold tracking-tight bg-white border border-neutral-300 shadow-sm" onClick={() => window.print()}>
            <Printer className="h-3.5 w-3.5 mr-1.5" />
            PRINT
          </Button>
          <Button size="sm" className="h-8 text-[10px] font-bold tracking-tight bg-primary hover:bg-primary/90 min-w-[100px] shadow-lg" onClick={handleSave} disabled={isSaving}>
            {isSaving ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Save className="h-3.5 w-3.5 mr-1.5" />}
            {isSaving ? 'SAVING...' : 'SAVE RECORD'}
          </Button>
        </div>
      </div>

      <div className="max-w-[1000px] mx-auto bg-white border border-neutral-300 shadow-xl p-10 print:p-0 print:border-none print:shadow-none min-h-[1200px] text-black font-serif text-[11px] leading-tight overflow-hidden transition-all">
        
        <div className="relative flex flex-col items-center mb-8">
          <div className="text-center space-y-0.5 mt-2 w-full max-w-[600px]">
            <input className="w-full text-center text-[10px] uppercase font-medium tracking-wide bg-transparent border-none outline-none focus:ring-1 focus:ring-primary/20 rounded px-1" value={headerData.republic || ''} onChange={(e) => setHeaderData({...headerData, republic: e.target.value})} />
            <input className="w-full text-center text-[16px] font-bold uppercase tracking-widest text-neutral-900 bg-transparent border-none outline-none focus:ring-1 focus:ring-primary/20 rounded px-1" value={headerData.university || ''} onChange={(e) => setHeaderData({...headerData, university: e.target.value})} />
            <input className="w-full text-center text-[11px] font-medium bg-transparent border-none outline-none focus:ring-1 focus:ring-primary/20 rounded px-1" value={headerData.location || ''} onChange={(e) => setHeaderData({...headerData, location: e.target.value})} />
            <div className="h-0.5 w-40 bg-black/10 mx-auto my-2" />
            <input className="w-full text-center text-[12px] uppercase font-bold text-neutral-800 bg-transparent border-none outline-none focus:ring-1 focus:ring-primary/20 rounded px-1" value={headerData.college || ''} onChange={(e) => setHeaderData({...headerData, college: e.target.value})} />
          </div>
          
          <div 
            className="absolute right-0 top-0 border-[1.5px] border-black/80 w-28 h-28 flex items-center justify-center text-center p-0 leading-none bg-neutral-50/50 overflow-hidden cursor-pointer group no-print"
            onClick={() => fileInputRef.current?.click()}
          >
            {photoUrl ? (
              <img src={photoUrl} alt="2x2 ID" className="w-full h-full object-cover" />
            ) : (
              <div className="flex flex-col items-center gap-1">
                <Camera className="h-6 w-6 text-neutral-300 group-hover:text-primary transition-colors" />
                <span className="font-bold text-[8px] text-neutral-400">UPLOAD PHOTO</span>
              </div>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleImageUpload} 
            />
          </div>
          <div className="hidden print:block absolute right-0 top-0 border-[1.5px] border-black/80 w-28 h-28 overflow-hidden">
             {photoUrl ? <img src={photoUrl} alt="ID" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-[8px] text-neutral-300">2x2 PHOTO</div>}
          </div>
        </div>

        <div className="text-center mb-6">
          <p className="text-[14px] font-bold uppercase tracking-widest border-b-[1.5px] border-black inline-block pb-0.5">PROSPECTUS IN</p>
          <div className="mt-3 space-y-1">
            <input className="w-full text-center text-[13px] font-bold uppercase text-neutral-900 bg-transparent border-none outline-none focus:ring-1 focus:ring-primary/20 rounded px-1" value={headerData.degree || ''} onChange={(e) => setHeaderData({...headerData, degree: e.target.value})} />
            <input className="w-full text-center text-[10px] italic font-medium text-neutral-500 bg-transparent border-none outline-none focus:ring-1 focus:ring-primary/20 rounded px-1" value={headerData.basis || ''} onChange={(e) => setHeaderData({...headerData, basis: e.target.value})} />
          </div>
        </div>

        <div className="grid grid-cols-12 gap-x-4 gap-y-2 mt-6 mb-8 border-t-2 border-black pt-4">
          <div className="col-span-8 flex flex-col">
            <div className="flex border-b border-black pb-0.5">
              <span className="font-bold min-w-[50px] text-[10px] uppercase">Name:</span>
              <input className="flex-1 px-2 uppercase font-bold text-[12px] bg-transparent outline-none border-none placeholder:text-neutral-200" placeholder="LAST NAME, FIRST NAME M." value={prospectusData.studentInfo.name || ''} onChange={(e) => handleStudentInfoChange('name', e.target.value)} />
            </div>
          </div>
          <div className="col-span-4 flex border-b border-black pb-0.5 items-end">
            <span className="font-bold min-w-[90px] text-[10px] uppercase">Student I.D No.:</span>
            <input className="flex-1 px-2 font-mono font-bold text-neutral-800 tracking-wider bg-transparent outline-none border-none" placeholder="20XX-XXXXX" value={prospectusData.studentInfo.id || ''} onChange={(e) => handleStudentInfoChange('id', e.target.value)} />
          </div>
          <div className="col-span-8 flex border-b border-black pb-0.5">
            <span className="font-bold min-w-[120px] text-[10px] uppercase">Permanent Address:</span>
            <input className="flex-1 px-2 font-medium bg-transparent outline-none border-none" placeholder="Full Address" value={prospectusData.studentInfo.permanentAddress || ''} onChange={(e) => handleStudentInfoChange('permanentAddress', e.target.value)} />
          </div>
          <div className="col-span-4 flex border-b border-black pb-0.5 items-end">
            <span className="font-bold min-w-[90px] text-[10px] uppercase">Cellphone No.:</span>
            <input className="flex-1 px-2 font-medium tracking-tighter bg-transparent outline-none border-none" placeholder="09XXXXXXXXX" value={prospectusData.studentInfo.phone || ''} onChange={(e) => handleStudentInfoChange('phone', e.target.value)} />
          </div>
        </div>

        {prospectusData.academicProspectus.map((year: any, yearIdx: number) => (
          <div key={year.name} className="mb-8 break-inside-avoid">
            <div className="bg-neutral-900 text-white py-1.5 text-center border border-black mb-1">
              <h3 className="font-bold text-[13px] uppercase tracking-[0.3em]">{year.name}</h3>
            </div>
            {year.semesters.map((sem: any, semIdx: number) => (
              <div key={sem.name} className="mb-6 last:mb-0">
                <div className="text-center py-1.5 font-bold uppercase text-[11px] bg-neutral-100 border-x border-b border-black mb-1 tracking-widest italic flex justify-between px-4 items-center">
                  <span>{sem.name || ''}</span>
                  <Button variant="ghost" size="sm" className="h-6 text-[8px] no-print hover:bg-neutral-200 text-primary border border-primary/20 bg-white" onClick={() => handleAddCourse(yearIdx, semIdx)}>
                    <Plus className="h-3 w-3 mr-1" /> ADD COURSE
                  </Button>
                </div>
                <table className="w-full border-collapse border border-black table-fixed">
                  <thead>
                    <tr className="bg-neutral-50 text-[8px] font-bold uppercase text-neutral-700">
                      <th className="border border-black px-1 py-1 w-[8%] leading-none">Yr./Sem Taken</th>
                      <th className="border border-black px-1 py-1 w-[8%]">Rating</th>
                      <th className="border border-black px-1 py-1 w-[12%]">Course Code</th>
                      <th className="border border-black px-1 py-1 w-[12%]">Univ. Code</th>
                      <th className="border border-black px-2 py-1 text-left w-[30%]">Course Description</th>
                      <th className="border border-black px-1 py-1 w-[6%]">Lec</th>
                      <th className="border border-black px-1 py-1 w-[6%]">Lab</th>
                      <th className="border border-black px-1 py-1 w-[6%]">Units</th>
                      <th className="border border-black px-1 py-1 w-[12%]">Prerequisite</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sem.courses.map((course: any, courseIdx: number) => (
                      <tr key={courseIdx} className={`text-[10px] h-7 group relative`}>
                        <td className="border border-black p-0 text-center font-mono text-[9px]">
                           <input className="w-full h-full p-1 text-center bg-transparent border-none outline-none no-print" value={course.yrSemTaken || ''} onChange={(e) => handleFieldChange(yearIdx, semIdx, courseIdx, 'yrSemTaken', e.target.value)} />
                           <span className="hidden print:block w-full text-center py-1">{course.yrSemTaken || ''}</span>
                        </td>
                        <td className={`border border-black p-0`}>
                          <input className="w-full h-full p-1 text-center bg-transparent border-none outline-none font-bold text-[12px] no-print" value={course.gradeRating || ''} onChange={(e) => handleFieldChange(yearIdx, semIdx, courseIdx, 'gradeRating', e.target.value)} />
                          <span className="hidden print:block w-full text-center font-bold text-[12px] py-1">{course.gradeRating || ''}</span>
                        </td>
                        <td className="border border-black p-0 text-center font-bold relative group">
                          <input className="w-full h-full p-1 text-center bg-transparent border-none outline-none font-bold no-print" value={course.courseCode || ''} onChange={(e) => handleFieldChange(yearIdx, semIdx, courseIdx, 'courseCode', e.target.value)} />
                          <span className="hidden print:block w-full text-center py-1">{course.courseCode || ''}</span>
                          <button className="absolute -left-6 top-1/2 -translate-y-1/2 text-red-500 opacity-0 group-hover:opacity-100 no-print transition-opacity p-1 hover:bg-red-50 rounded" onClick={() => handleRemoveCourse(yearIdx, semIdx, courseIdx)}>
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </td>
                        <td className="border border-black p-0 text-center">
                          <input className="w-full h-full p-1 text-center bg-transparent border-none outline-none text-[9px] no-print" value={course.universityCode || ''} onChange={(e) => handleFieldChange(yearIdx, semIdx, courseIdx, 'universityCode', e.target.value)} />
                          <span className="hidden print:block w-full text-center text-[9px] py-1">{course.universityCode || ''}</span>
                        </td>
                        <td className="border border-black p-0 text-left">
                          <input className="w-full h-full p-1 px-2 bg-transparent border-none outline-none truncate no-print" value={course.courseDescription || ''} onChange={(e) => handleFieldChange(yearIdx, semIdx, courseIdx, 'courseDescription', e.target.value)} />
                          <span className="hidden print:block w-full text-left px-2 py-1 truncate">{course.courseDescription || ''}</span>
                        </td>
                        <td className="border border-black p-0 text-center"><input type="number" className="w-full h-full p-1 text-center bg-transparent border-none outline-none no-print" value={course.lectureHours || 0} onChange={(e) => handleFieldChange(yearIdx, semIdx, courseIdx, 'lectureHours', parseInt(e.target.value) || 0)} /><span className="hidden print:block">{course.lectureHours}</span></td>
                        <td className="border border-black p-0 text-center"><input type="number" className="w-full h-full p-1 text-center bg-transparent border-none outline-none no-print" value={course.labHours || 0} onChange={(e) => handleFieldChange(yearIdx, semIdx, courseIdx, 'labHours', parseInt(e.target.value) || 0)} /><span className="hidden print:block">{course.labHours}</span></td>
                        <td className="border border-black p-0 text-center font-bold"><input type="number" className="w-full h-full p-1 text-center bg-transparent border-none outline-none font-bold no-print" value={course.totalCreditUnits || 0} onChange={(e) => handleFieldChange(yearIdx, semIdx, courseIdx, 'totalCreditUnits', parseInt(e.target.value) || 0)} /><span className="hidden print:block">{course.totalCreditUnits}</span></td>
                        <td className="border border-black p-0 text-center italic text-[8px]"><input className="w-full h-full p-1 text-center bg-transparent border-none outline-none italic text-[8px] no-print" value={course.prerequisite || ''} onChange={(e) => handleFieldChange(yearIdx, semIdx, courseIdx, 'prerequisite', e.target.value)} /><span className="hidden print:block">{course.prerequisite || 'None'}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="grid grid-cols-12 mt-2 px-1 text-[10px] items-center">
                  <div className="col-span-2 flex items-center gap-1">
                    <span className="font-bold text-neutral-600">GWA:</span>
                    <span className="border-b-[1.5px] border-black px-3 min-w-[50px] inline-block text-center font-bold text-[12px]">{calculateGWA(sem.courses)}</span>
                  </div>
                  <div className="col-span-6 flex flex-col items-center">
                    <input className="w-full border-b border-black text-center uppercase font-bold text-neutral-800 pb-0.5 bg-transparent outline-none placeholder:text-neutral-200" placeholder="ADVISER NAME" value={sem.programAdviserName || ''} onChange={(e) => handleSemesterFieldChange(yearIdx, semIdx, 'programAdviserName', e.target.value)} />
                    <span className="text-[8px] font-bold uppercase text-neutral-400 mt-0.5 tracking-tighter">Program Adviser (Signature over Printed Name)</span>
                  </div>
                  <div className="col-span-4 flex flex-col items-center pl-4">
                    <input className="w-full border-b border-black text-center font-medium pb-0.5 tracking-widest bg-transparent outline-none" placeholder="" value={sem.dateEvaluated || ''} onChange={(e) => handleSemesterFieldChange(yearIdx, semIdx, 'dateEvaluated', e.target.value)} />
                    <span className="text-[8px] font-bold uppercase text-neutral-400 mt-0.5 tracking-tighter">Date Evaluated</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ))}

        <div className="mt-10 grid grid-cols-2 gap-10 border-t-2 border-black pt-6 break-inside-avoid">
          <div>
            <h4 className="font-bold uppercase text-[11px] border-b border-black mb-3 pb-1 tracking-widest">Summary of Units Required</h4>
            <div className="space-y-1.5 px-2">
              <div className="flex justify-between items-center"><span className="font-medium">General Education Subjects:</span><input type="number" className="font-bold border-b border-black w-12 text-center bg-transparent outline-none" value={prospectusData.summaryOfUnits.generalEducation || 0} onChange={(e) => setProspectusData({...prospectusData, summaryOfUnits: {...prospectusData.summaryOfUnits, generalEducation: parseInt(e.target.value) || 0}})} /></div>
              <div className="flex justify-between items-center"><span className="font-medium">Professional Courses:</span><input type="number" className="font-bold border-b border-black w-12 text-center bg-transparent outline-none" value={prospectusData.summaryOfUnits.professionalCourses || 0} onChange={(e) => setProspectusData({...prospectusData, summaryOfUnits: {...prospectusData.summaryOfUnits, professionalCourses: parseInt(e.target.value) || 0}})} /></div>
              <div className="flex justify-between items-center"><span className="font-medium">Major Courses:</span><input type="number" className="font-bold border-b border-black w-12 text-center bg-transparent outline-none" value={prospectusData.summaryOfUnits.majorCourses || 0} onChange={(e) => setProspectusData({...prospectusData, summaryOfUnits: {...prospectusData.summaryOfUnits, majorCourses: parseInt(e.target.value) || 0}})} /></div>
              <div className="flex justify-between items-center pt-1 border-t border-neutral-200 mt-1"><span className="font-bold uppercase text-[10px]">Total Units Required:</span><span className="font-black border-b-2 border-black min-w-[40px] text-center text-[12px]">{prospectusData.summaryOfUnits.generalEducation + prospectusData.summaryOfUnits.professionalCourses + prospectusData.summaryOfUnits.majorCourses}</span></div>
            </div>
          </div>
          <div className="flex flex-col">
            <h4 className="font-bold uppercase text-[11px] border-b border-black mb-3 pb-1 tracking-widest">OJT / Internship Section</h4>
            <div className="bg-neutral-50 p-4 border border-black/10 rounded flex-1 flex flex-col items-center justify-center text-center">
              <p className="font-bold text-[12px] uppercase">OJT Requirement</p>
              <div className="flex items-baseline gap-2">
                <input type="number" className="text-[18px] font-black text-primary my-1 bg-transparent border-b-2 border-primary outline-none w-20 text-center" value={prospectusData.ojtSection.hours || 0} onChange={(e) => setProspectusData({...prospectusData, ojtSection: { hours: parseInt(e.target.value) || 0 }})} />
                <span className="font-black text-primary">HOURS</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center text-[9px] text-neutral-400 italic">
          Disclaimer: This is an unofficial academic profile intended for evaluation purposes only.
        </div>
      </div>
    </div>
  );
}
