"use client";

import { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Mail, Loader2, ArrowLeft, CheckCircle2, Info, AlertTriangle } from 'lucide-react';
import { useAuth, initiatePasswordReset } from '@/firebase';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function ResetPasswordPage() {
  const auth = useAuth();
  const { toast } = useToast();
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSent, setIsSent] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    if (!email) return;

    setIsSubmitting(true);
    try {
      // Standard Firebase: Sends a secure password reset link to the email.
      // Important: Ensure Email/Password provider is enabled in your Firebase Console.
      await initiatePasswordReset(auth, email);
      setIsSent(true);
      toast({
        title: "Recovery Dispatched",
        description: `A secure reset link is on its way to ${email}.`,
      });
    } catch (error: any) {
      console.error("Password reset error:", error);
      let message = "Could not send reset link. Please verify the email address.";
      
      if (error.code === 'auth/invalid-email') {
        message = "The email address format is invalid.";
      } else if (error.code === 'auth/user-not-found') {
        message = "No account found with this institutional email.";
      } else if (error.code === 'auth/too-many-requests') {
        message = "Too many attempts. Please try again later for security.";
      }
      
      setErrorMessage(message);
      toast({
        variant: "destructive",
        title: "Reset Failed",
        description: message,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-neutral-50 p-4">
      <Card className="w-full max-w-md shadow-2xl border-t-8 border-t-accent rounded-3xl overflow-hidden">
        <CardHeader className="space-y-1 text-center pb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-accent/5 p-4 rounded-full">
              <Mail className="h-10 w-10 text-accent" />
            </div>
          </div>
          <CardTitle className="text-3xl font-black text-secondary tracking-tight uppercase">Reset Password</CardTitle>
          <CardDescription className="font-medium">
            Retrieve your account through a secure email link.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {isSent ? (
            <div className="space-y-6">
              <div className="bg-green-50 border border-green-200 rounded-2xl p-6 text-center space-y-4">
                <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto" />
                <p className="font-bold text-green-800">Check Your Inbox!</p>
                <p className="text-sm text-green-700">We've sent a password reset link to <strong>{email}</strong>.</p>
              </div>
              
              <Alert className="bg-blue-50 border-blue-200 text-blue-800">
                <Info className="h-4 w-4" />
                <AlertTitle className="font-bold">Missing the email?</AlertTitle>
                <AlertDescription className="text-xs">
                  Please check your <strong>Spam</strong> or <strong>Junk</strong> folder. Sometimes institutional filters redirect external recovery links.
                </AlertDescription>
              </Alert>

              <Button 
                variant="outline" 
                className="w-full h-12 rounded-xl font-bold" 
                onClick={() => setIsSent(false)}
              >
                Try a different email
              </Button>
            </div>
          ) : (
            <form onSubmit={handleReset} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Institutional Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-400 z-10" />
                  <Input 
                    id="email" 
                    type="email" 
                    placeholder="name@university.edu" 
                    className="pl-10 h-12 rounded-xl"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required 
                  />
                </div>
              </div>
              
              {errorMessage && (
                <Alert variant="destructive" className="rounded-xl border-destructive/20 bg-destructive/5">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-xs font-medium">
                    {errorMessage}
                  </AlertDescription>
                </Alert>
              )}

              <div className="bg-neutral-100 border border-neutral-200 rounded-xl p-4">
                <p className="text-[11px] leading-relaxed text-neutral-500 italic">
                  <strong>Note:</strong> Your academic records and student evaluations are linked to this email. Resetting your password will grant you access back to all your data securely.
                </p>
              </div>

              <Button type="submit" className="w-full h-12 bg-accent hover:bg-accent/90 font-black uppercase tracking-widest rounded-xl shadow-lg mt-2 text-white" disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Send Recovery Link
              </Button>
            </form>
          )}
        </CardContent>
        <CardFooter className="flex flex-col space-y-4 bg-neutral-50/50 py-6">
          <Link href="/auth/login" className="flex items-center text-[10px] font-black text-primary uppercase tracking-widest hover:underline">
            <ArrowLeft className="h-3 w-3 mr-2" />
            Return to Login
          </Link>
        </CardFooter>
      </Card>
    </div>
  );
}
