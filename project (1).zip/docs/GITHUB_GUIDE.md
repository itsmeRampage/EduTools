# Step-by-Step GitHub Upload Guide for EduTools

Follow these steps to get your code into `https://github.com/itsmeRampage/EduTools.git`.

## Method 1: Drag and Drop (Easiest)
1. Open your repository: [https://github.com/itsmeRampage/EduTools](https://github.com/itsmeRampage/EduTools)
2. Look for a link that says **"uploading an existing file"** (it's usually in a blue box if the repo is empty).
3. Open your project folder on your computer.
4. **Select ALL files and folders** (src, public, package.json, etc.).
5. **Drag and Drop** them into the GitHub browser window.
6. Wait for the progress bar to finish (it might take a minute).
7. Scroll down and click the green **"Commit changes"** button.

## Method 2: Terminal (Advanced)
If you prefer the terminal, run these commands:
```bash
git init
git add .
git commit -m "Initialize EDUProfile Production"
git branch -M main
git remote add origin https://github.com/itsmeRampage/EduTools.git
git push -u origin main
```

### IMPORTANT: Verify the Upload
After uploading, refresh your GitHub page. You **MUST** see the `src` folder and `package.json` file. If you don't see them, Vercel will say "Not Found".