"use client";

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { GraduationCap, ShieldCheck, BookOpen, ArrowRight, CheckCircle2, Users, Award } from 'lucide-react';
import { useUser } from '@/firebase';

export default function Home() {
  const { user } = useUser();

  return (
    <div className="flex flex-col min-h-screen bg-white">
      {/* Navigation Header */}
      <header className="px-6 h-20 flex items-center border-b bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <Link className="flex items-center justify-center group" href="/">
          <div className="bg-primary p-2 rounded-xl mr-3 group-hover:scale-110 transition-transform">
            <GraduationCap className="h-6 w-6 text-white" />
          </div>
          <span className="font-black text-xl tracking-tighter text-secondary uppercase">EDUProfile</span>
        </Link>
        <nav className="ml-auto flex items-center gap-4">
          <Link href="/student-portal/login">
            <Button variant="ghost" className="font-black text-[10px] uppercase tracking-widest text-neutral-500 hover:text-primary">
              Student Portal
            </Button>
          </Link>
          {user ? (
            <Link href="/dashboard">
              <Button size="sm" className="bg-primary font-black text-[10px] uppercase tracking-widest rounded-xl shadow-lg px-6 h-10">
                Dashboard <ArrowRight className="h-3 w-3 ml-2" />
              </Button>
            </Link>
          ) : (
            <Link href="/auth/login">
              <Button size="sm" className="bg-secondary font-black text-[10px] uppercase tracking-widest rounded-xl shadow-lg px-6 h-10">
                Faculty Login
              </Button>
            </Link>
          )}
        </nav>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative w-full py-24 md:py-32 lg:py-48 overflow-hidden">
          <div className="absolute inset-0 bg-neutral-50 -z-10" />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[1000px] bg-primary/5 rounded-full blur-3xl -z-10" />
          
          <div className="container px-4 md:px-6 mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-[10px] font-black uppercase tracking-[0.2em] mb-8 animate-fade-in">
              <ShieldCheck className="h-3 w-3" /> Secure Academic Records
            </div>
            <h1 className="text-5xl font-black tracking-tight sm:text-6xl md:text-7xl lg:text-8xl text-secondary uppercase leading-[0.9] mb-8">
              The Standard for <br/>
              <span className="text-primary">Academic Excellence</span>
            </h1>
            <p className="mx-auto max-w-[800px] text-neutral-500 md:text-xl font-medium leading-relaxed mb-12">
              A comprehensive profiling system for faculty to manage prospectuses, evaluate student progress, and streamline institutional records with precision.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <Link href="/student-portal/login" className="w-full sm:w-auto">
                <Button size="lg" className="bg-primary hover:bg-primary/90 w-full sm:w-[240px] h-16 rounded-2xl font-black uppercase tracking-[0.2em] shadow-2xl text-white">
                  Student Portal
                </Button>
              </Link>
              <Link href="/auth/login" className="w-full sm:w-auto">
                <Button variant="outline" size="lg" className="w-full sm:w-[240px] h-16 rounded-2xl font-black uppercase tracking-[0.2em] border-neutral-200 hover:bg-neutral-50">
                  Faculty Entry
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="w-full py-32 bg-white">
          <div className="container px-4 md:px-6 mx-auto">
            <div className="text-center mb-20">
              <h2 className="text-3xl font-black text-secondary uppercase tracking-tight mb-4">Core Platform Capabilities</h2>
              <div className="h-1.5 w-20 bg-primary mx-auto rounded-full" />
            </div>
            <div className="grid gap-12 sm:grid-cols-2 lg:grid-cols-3">
              <div className="p-10 rounded-[2.5rem] bg-neutral-50 hover:bg-white hover:shadow-2xl hover:-translate-y-2 transition-all group">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-primary group-hover:text-white transition-colors">
                  <CheckCircle2 className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-black text-secondary uppercase mb-4">Official Prospectus</h3>
                <p className="text-neutral-500 font-medium leading-relaxed">
                  Real-time synchronization of curriculum evaluations. Locked grades ensure record integrity and accuracy across all terms.
                </p>
              </div>
              <div className="p-10 rounded-[2.5rem] bg-neutral-50 hover:bg-white hover:shadow-2xl hover:-translate-y-2 transition-all group">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-primary group-hover:text-white transition-colors">
                  <Users className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-black text-secondary uppercase mb-4">Student Portals</h3>
                <p className="text-neutral-500 font-medium leading-relaxed">
                  Personalized access for students to view evaluation sheets, register for courses, and manage their weekly class timetable.
                </p>
              </div>
              <div className="p-10 rounded-[2.5rem] bg-neutral-50 hover:bg-white hover:shadow-2xl hover:-translate-y-2 transition-all group">
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-primary group-hover:text-white transition-colors">
                  <Award className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-black text-secondary uppercase mb-4">GWA Calculation</h3>
                <p className="text-neutral-500 font-medium leading-relaxed">
                  Automated computation of General Weighted Average (GWA) based on official unit counts and descriptive course ratings.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-24 bg-primary text-white overflow-hidden relative">
          <div className="absolute right-0 top-0 translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-white/10 rounded-full blur-3xl" />
          <div className="container px-4 md:px-6 mx-auto text-center relative z-10">
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tight mb-6">Institutional Grade Security</h2>
            <p className="text-white/70 max-w-2xl mx-auto mb-10 text-lg font-medium">
              Join thousands of faculty members in standardizing academic record management with EDUProfile.
            </p>
            <Link href="/auth/register">
              <Button size="lg" className="bg-white text-primary hover:bg-neutral-100 font-black uppercase tracking-[0.2em] h-16 px-12 rounded-2xl shadow-xl">
                Create Faculty Account
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="py-12 px-6 border-t bg-neutral-50">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
            <GraduationCap className="h-6 w-6 text-neutral-300" />
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-neutral-400">© 2026 EDUProfile Management System</span>
          </div>
          <nav className="flex gap-8">
            <Link href="#" className="text-[10px] font-black uppercase text-neutral-400 hover:text-primary tracking-widest transition-colors">Faculty Support</Link>
            <Link href="#" className="text-[10px] font-black uppercase text-neutral-400 hover:text-primary tracking-widest transition-colors">Privacy Policy</Link>
            <Link href="#" className="text-[10px] font-black uppercase text-neutral-400 hover:text-primary tracking-widest transition-colors">Terms of Service</Link>
          </nav>
        </div>
      </footer>
    </div>
  );
}
