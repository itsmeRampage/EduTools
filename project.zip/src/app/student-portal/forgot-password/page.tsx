"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Key, User, ArrowLeft, Loader2, CheckCircle2, ShieldAlert } from 'lucide-react';
import { useFirestore, updateDocumentNonBlocking } from '@/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';

export default function StudentForgotPassword() {
  const router = useRouter();
  const db = useFirestore();
  const { toast } = useToast();
  
  const [studentId, setStudentId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isReset, setIsReset] = useState(false);

  const handleResetToId = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedId = studentId.trim();
    if (!trimmedId) return;

    setIsLoading(true);
    
    try {
      const globalDocRef = doc(db, 'students', trimmedId);
      const snap = await getDoc(globalDocRef);
      
      if (snap.exists()) {
        const data = snap.data();
        const profId = data.managingProfessorId;
        
        // Reset logic: Password reverts to Student ID for simple recovery
        const payload = { 
          portalPassword: trimmedId,
          lastSecurityReset: new Date().toISOString()
        };

        // Update global registry for login
        updateDocumentNonBlocking(globalDocRef, payload);

        // Update professor's student record
        if (profId) {
          const profStudentRef = doc(db, 'professors', profId, 'students', trimmedId);
          updateDocumentNonBlocking(profStudentRef, payload);
        }

        setIsReset(true);
        toast({
          title: "Access Reverted",
          description: "Your Access Key has been reset to your Student ID.",
        });
      } else {
        toast({
          variant: "destructive",
          title: "ID Not Registered",
          description: "This Student ID was not found in our records.",
        });
      }
    } catch (err) {
      toast({ variant: "destructive", title: "Error", description: "System failure during reset." });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-neutral-50 p-4">
      <Card className="w-full max-w-md shadow-2xl border-t-8 border-t-primary rounded-3xl overflow-hidden bg-white">
        <CardHeader className="space-y-1 text-center pb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-primary/5 p-4 rounded-full">
              <Key className="h-10 w-10 text-primary" />
            </div>
          </div>
          <CardTitle className="text-3xl font-black text-secondary tracking-tight uppercase">Recover Access</CardTitle>
          <CardDescription className="font-medium">
            Reset your Access Key using your Student ID.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {isReset ? (
            <div className="space-y-6">
              <div className="bg-green-50 p-6 rounded-2xl border border-green-200 text-center space-y-4">
                <CheckCircle2 className="h-12 w-12 text-green-500 mx-auto" />
                <p className="font-black text-green-900 uppercase text-sm">Reset Successful</p>
                <p className="text-xs text-green-800 leading-relaxed">
                  Your Access Key is now your **Student ID**. Log in now to set a private password.
                </p>
              </div>
              <Link href="/student-portal/login" className="block">
                <Button className="w-full h-12 bg-primary font-black uppercase tracking-widest rounded-xl">
                  Go to Login
                </Button>
              </Link>
            </div>
          ) : (
            <form onSubmit={handleResetToId} className="space-y-4">
              <div className="space-y-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Enter Student ID</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-400" />
                  <input 
                    placeholder="2024-XXXXX" 
                    className="flex h-12 w-full rounded-xl border border-neutral-200 bg-background px-3 py-2 text-sm pl-10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    required 
                  />
                </div>
              </div>

              <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 flex gap-3">
                <ShieldAlert className="h-5 w-5 text-neutral-400 shrink-0" />
                <p className="text-[9px] text-neutral-500 leading-relaxed">
                  Resetting will revert your password to your ID number. You can change this once you log in.
                </p>
              </div>

              <Button type="submit" className="w-full h-12 bg-primary font-black uppercase tracking-widest rounded-xl shadow-lg" disabled={isLoading}>
                {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Reset Access Key"}
              </Button>
            </form>
          )}
        </CardContent>
        <CardFooter className="flex flex-col space-y-4 bg-neutral-100/30 py-6">
          <Link href="/student-portal/login" className="flex items-center text-[10px] font-black text-neutral-400 uppercase tracking-widest hover:text-primary">
            <ArrowLeft className="h-3 w-3 mr-2" />
            Back to Login
          </Link>
        </CardFooter>
      </Card>
    </div>
  );
}