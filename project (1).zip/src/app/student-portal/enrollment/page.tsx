
"use client";

import { useEffect, useState, useMemo, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { CheckCircle2, Calendar, Clock, MapPin, Loader2, Info, ArrowLeft } from 'lucide-react';
import { 
  useFirestore, 
  useCollection,
  useMemoFirebase,
  setDocumentNonBlocking,
  deleteDocumentNonBlocking,
  updateDocumentNonBlocking
} from '@/firebase';
import { doc, collection, query, where, increment } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

function EnrollmentView() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const db = useFirestore();
  const { toast } = useToast();
  
  const profId = searchParams.get('prof');
  const studentId = searchParams.get('sid');

  const schedulesRef = useMemoFirebase(() => collection(db, 'schedules'), [db]);
  const { data: schedules, isLoading: isSchedLoading } = useCollection(schedulesRef);

  const enrollmentsQuery = useMemoFirebase(() => {
    if (!studentId) return null;
    return query(collection(db, 'enrollments'), where('studentId', '==', studentId));
  }, [db, studentId]);
  const { data: enrollments, isLoading: isEnrolLoading } = useCollection(enrollmentsQuery);

  const handleEnroll = async (sched: any) => {
    if (!studentId) return;
    
    const hasConflict = (enrollments || []).some((e: any) => {
      const es = (schedules || []).find((s: any) => s.id === e.scheduleId);
      if (!es) return false;
      
      const startA = sched.startTime;
      const endA = sched.endTime;
      const startB = es.startTime;
      const endB = es.endTime;

      return es.day === sched.day && (
        (startA >= startB && startA < endB) || 
        (endA > startB && endA <= endB) ||     
        (startB >= startA && startB < endA)    
      );
    });

    if (hasConflict) {
      toast({ variant: "destructive", title: "Schedule Conflict", description: "This class overlaps with an existing subject." });
      return;
    }

    const enrollmentId = `en-${studentId}-${sched.id}`;
    setDocumentNonBlocking(doc(db, 'enrollments', enrollmentId), {
      id: enrollmentId,
      studentId,
      scheduleId: sched.id,
      subjectCode: sched.subjectCode,
      enrolledAt: new Date().toISOString()
    }, { merge: true });

    updateDocumentNonBlocking(doc(db, 'schedules', sched.id), { enrolledCount: increment(1) });
    toast({ title: "Enrolled Successfully", description: `Joined ${sched.subjectCode}.` });
  };

  const handleDrop = async (sched: any) => {
    const eid = enrollments?.find((e: any) => e.scheduleId === sched.id)?.id;
    if (eid) {
      deleteDocumentNonBlocking(doc(db, 'enrollments', eid));
      updateDocumentNonBlocking(doc(db, 'schedules', sched.id), { enrolledCount: increment(-1) });
      toast({ title: "Course Dropped", description: "Removed from subject." });
    }
  };

  if (isSchedLoading || isEnrolLoading) return <div className="flex justify-center py-20"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>;

  const queryParams = `?prof=${profId}&sid=${studentId}`;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-2">
        <Link href={`/student-portal/prospectus${queryParams}`}>
          <Button variant="outline" size="icon" className="h-9 w-9 rounded-full border-neutral-300 bg-white shadow-sm">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h2 className="text-2xl font-black uppercase tracking-tight text-secondary">Course Registration</h2>
      </div>

      <div className="flex justify-between items-center">
        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground">Available Term Subjects</p>
        <div className="bg-white px-4 py-2 rounded-xl border font-black text-[10px] uppercase tracking-widest text-primary shadow-sm">
          Active Units: {(enrollments?.length || 0) * 3} 
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {schedules?.map((sched: any) => {
          const isEnrolled = enrollments?.some((e: any) => e.scheduleId === sched.id);
          const isFull = sched.enrolledCount >= (sched.maxStudents || 0);
          
          return (
            <Card key={sched.id} className={cn(
              "rounded-2xl border-none shadow-lg overflow-hidden transition-all hover:shadow-xl",
              isEnrolled ? "ring-2 ring-primary" : ""
            )}>
              <div className={cn("p-6", isEnrolled ? "bg-primary text-white" : "bg-white")}>
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-lg font-black uppercase flex items-center gap-2">
                      {sched.subjectCode}
                      {isEnrolled && <CheckCircle2 className="h-4 w-4" />}
                    </h4>
                    <p className={cn("text-[10px] font-bold uppercase tracking-tight mt-1", isEnrolled ? "text-white/70" : "text-muted-foreground")}>
                      {sched.subjectName}
                    </p>
                  </div>
                  <div className={cn("px-2 py-1 rounded text-[9px] font-black uppercase", isEnrolled ? "bg-white/20" : "bg-neutral-100")}>
                    {sched.enrolledCount || 0} / {sched.maxStudents || 0}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase">
                    <Calendar className="h-3 w-3 opacity-50" /> {sched.day}
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase">
                    <Clock className="h-3 w-3 opacity-50" /> {sched.startTime} - {sched.endTime}
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase col-span-2">
                    <MapPin className="h-3 w-3 opacity-50" /> {sched.room}
                  </div>
                </div>

                <div className="mt-8">
                  {isEnrolled ? (
                    <Button variant="outline" className="w-full h-11 rounded-xl bg-white/10 border-white/20 text-white hover:bg-white hover:text-red-500 font-black text-[10px] uppercase tracking-widest" onClick={() => handleDrop(sched)}>
                      Drop Course
                    </Button>
                  ) : (
                    <Button className="w-full h-11 rounded-xl bg-secondary hover:bg-secondary/90 font-black text-[10px] uppercase tracking-widest" disabled={isFull} onClick={() => handleEnroll(sched)}>
                      {isFull ? 'Section Full' : 'Enroll Now'}
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          );
        })}
        {schedules?.length === 0 && (
          <div className="col-span-full py-20 text-center bg-white rounded-2xl border border-dashed border-neutral-300">
            <Info className="h-10 w-10 text-neutral-200 mx-auto mb-4" />
            <p className="text-sm font-bold text-muted-foreground uppercase">No subjects available for registration.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function StudentEnrollmentPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>}>
      <EnrollmentView />
    </Suspense>
  );
}
