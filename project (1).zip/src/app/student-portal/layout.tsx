
"use client";

import { useEffect, useState, Suspense } from 'react';
import { useRouter, useSearchParams, usePathname } from 'next/navigation';
import Link from 'next/link';
import { GraduationCap, LogOut, FileText, ClipboardList, Calendar, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

function StudentPortalNav() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const profId = searchParams.get('prof');
  const studentId = searchParams.get('sid');
  const [session, setSession] = useState<any>(null);

  useEffect(() => {
    const savedSession = sessionStorage.getItem('student_portal_session');
    const isAuthPage = pathname.includes('/login') || pathname.includes('/forgot-password');

    if (!savedSession) {
      if (!isAuthPage) {
        router.push('/student-portal/login');
      }
      return;
    }
    setSession(JSON.parse(savedSession));
  }, [router, pathname]);

  const navItems = [
    { label: 'Prospectus', icon: FileText, href: '/student-portal/prospectus' },
    { label: 'Enrollment', icon: ClipboardList, href: '/student-portal/enrollment' },
    { label: 'Timetable', icon: Calendar, href: '/student-portal/timetable' },
  ];

  const isAuthPage = pathname.includes('/login') || pathname.includes('/forgot-password');

  // Hide navigation entirely on login or forgot-password pages, or if no session exists
  if (isAuthPage || !session) return null;

  const currentProf = profId || session.profId;
  const currentSid = studentId || session.studentId;
  const queryParams = `?prof=${currentProf}&sid=${currentSid}`;

  return (
    <header className="h-20 border-b bg-white sticky top-0 z-40 shadow-sm px-4 md:px-8 no-print">
      <div className="max-w-[1200px] mx-auto h-full flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-primary/5 p-2 rounded-xl">
            <GraduationCap className="h-7 w-7 text-primary" />
          </div>
          <div className="hidden sm:block">
            <h1 className="text-sm font-black uppercase tracking-tight text-secondary leading-none">
              {session.name || 'STUDENT'}
            </h1>
            <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest mt-1">
              {session.studentId} • PORTAL
            </p>
          </div>
        </div>

        <nav className="flex items-center gap-1 md:gap-2">
          {navItems.map((item) => (
            <Link key={item.href} href={`${item.href}${queryParams}`}>
              <Button 
                variant={pathname === item.href ? 'default' : 'ghost'} 
                size="sm" 
                className={cn(
                  "h-10 rounded-xl px-3 md:px-4 font-black text-[10px] uppercase tracking-widest",
                  pathname === item.href ? "shadow-md" : "text-muted-foreground"
                )}
              >
                <item.icon className="h-4 w-4 md:mr-2" />
                <span className="hidden lg:inline">{item.label}</span>
              </Button>
            </Link>
          ))}
        </nav>

        <Button 
          variant="outline" 
          size="sm" 
          className="rounded-xl border-red-100 text-red-500 hover:bg-red-50 font-black text-[10px] uppercase tracking-widest px-4"
          onClick={() => {
            sessionStorage.removeItem('student_portal_session');
            router.push('/student-portal/login');
          }}
        >
          <LogOut className="h-3.5 w-3.5 mr-2" />
          <span className="hidden sm:inline">Logout</span>
        </Button>
      </div>
    </header>
  );
}

export default function StudentPortalLayout({ children }: { children: React.ReactNode }) {
  return (
    <Suspense fallback={<div className="flex items-center justify-center min-h-screen"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>}>
      <div className="flex flex-col min-h-screen bg-neutral-100">
        <StudentPortalNav />
        <main className="flex-1 p-4 md:p-8">
          <div className="max-w-[1200px] mx-auto">
            {children}
          </div>
        </main>
      </div>
    </Suspense>
  );
}
