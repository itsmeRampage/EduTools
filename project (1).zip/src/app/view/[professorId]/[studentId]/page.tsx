"use client";

import { use, useMemo } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { 
  ArrowLeft, 
  Printer, 
  GraduationCap,
  Info,
  Loader2,
  Lock
} from 'lucide-react';
import { 
  useFirestore, 
  useDoc, 
  useMemoFirebase 
} from '@/firebase';
import { doc } from 'firebase/firestore';

export default function PublicStudentView({ params }: { params: Promise<{ professorId: string, studentId: string }> }) {
  const { professorId, studentId } = use(params);
  const db = useFirestore();

  const studentDocRef = useMemoFirebase(() => {
    return doc(db, 'professors', professorId, 'students', studentId);
  }, [db, professorId, studentId]);

  const { data: record, isLoading, error } = useDoc(studentDocRef);

  const calculateGWA = (courses: any[]) => {
    if (!courses || courses.length === 0) return '---';
    let totalQualityPoints = 0;
    let totalUnits = 0;
    courses.forEach(c => {
      const grade = parseFloat(c.gradeRating);
      const units = parseFloat(c.totalCreditUnits);
      if (!isNaN(grade) && grade > 0 && !isNaN(units)) {
        totalQualityPoints += (grade * units);
        totalUnits += units;
      }
    });
    return totalUnits === 0 ? '---' : (totalQualityPoints / totalUnits).toFixed(2);
  };

  const getGradeStatus = (course: any, allCourses: any[]) => {
    const failedCodes = new Set(
      allCourses
        .filter(c => parseFloat(c.gradeRating) > 3.0)
        .map(c => c.courseCode?.trim().toUpperCase())
    );
    
    if (course.prerequisite) {
      const prereqs = course.prerequisite.split(/[,&/]/).map((p: string) => p.trim().toUpperCase());
      if (prereqs.some((p: string) => failedCodes.has(p))) return 'restricted';
    }

    const grade = parseFloat(course.gradeRating);
    if (isNaN(grade)) return 'pending';
    if (grade >= 1.0 && grade <= 3.0) return 'passed';
    if (grade > 3.0) return 'failed';
    return 'incomplete';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !record || !record.prospectusData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen text-center px-4">
        <Lock className="h-12 w-12 text-muted-foreground mb-4 opacity-20" />
        <h2 className="text-xl font-bold">Record Not Found</h2>
        <p className="text-muted-foreground mt-2">The academic evaluation you are looking for is either private or does not exist.</p>
        <Link href="/" className="mt-6">
          <Button variant="outline">Back to Homepage</Button>
        </Link>
      </div>
    );
  }

  const { prospectusData, headerData } = record;
  const allFlattenedCourses = prospectusData.academicProspectus.flatMap((y: any) => y.semesters.flatMap((s: any) => s.courses));

  return (
    <div className="min-h-screen bg-neutral-100 p-0 md:p-8">
      <div className="no-print max-w-[1000px] mx-auto flex items-center justify-between mb-4 px-4 md:px-0">
        <div className="flex items-center gap-2">
          <GraduationCap className="h-5 w-5 text-primary" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-neutral-500">Official Student Copy</span>
        </div>
        <Button variant="secondary" size="sm" className="h-8 text-[10px] font-bold tracking-tight bg-white border border-neutral-300" onClick={() => window.print()}>
          <Printer className="h-3.5 w-3.5 mr-1.5" />
          PRINT EVALUATION
        </Button>
      </div>

      <div className="max-w-[1000px] mx-auto bg-white border border-neutral-300 shadow-lg p-10 print:p-0 print:border-none print:shadow-none min-h-[1200px] text-black font-serif text-[11px] leading-tight">
        
        <div className="text-center space-y-0.5 mb-8">
          <p className="text-[10px] uppercase font-medium">{headerData.republic}</p>
          <p className="text-[15px] font-bold uppercase tracking-widest">{headerData.university}</p>
          <p className="text-[11px] font-medium">{headerData.location}</p>
          <div className="h-0.5 w-40 bg-black/10 mx-auto my-2" />
          <p className="text-[12px] uppercase font-bold text-neutral-800">{headerData.college}</p>
        </div>

        <div className="text-center mb-6">
          <p className="text-[14px] font-bold uppercase tracking-widest border-b-[1.5px] border-black inline-block pb-0.5">PROSPECTUS IN</p>
          <p className="text-[13px] font-bold uppercase text-neutral-900 mt-3">{headerData.degree}</p>
          <p className="text-[10px] italic font-medium text-neutral-500">{headerData.basis}</p>
        </div>

        <div className="grid grid-cols-12 gap-x-4 gap-y-2 mt-6 mb-8 border-t-2 border-black pt-4">
          <div className="col-span-8 flex border-b border-black pb-0.5">
            <span className="font-bold min-w-[50px] text-[10px] uppercase">Name:</span>
            <span className="flex-1 px-2 uppercase font-bold text-[12px]">{prospectusData.studentInfo.name}</span>
          </div>
          <div className="col-span-4 flex border-b border-black pb-0.5">
            <span className="font-bold min-w-[90px] text-[10px] uppercase">Student I.D No.:</span>
            <span className="flex-1 px-2 font-mono font-bold">{prospectusData.studentInfo.id}</span>
          </div>
        </div>

        {prospectusData.academicProspectus.map((year: any) => (
          <div key={year.name} className="mb-8 break-inside-avoid">
            <div className="bg-neutral-900 text-white py-1.5 text-center border border-black mb-1 font-bold text-[13px] uppercase tracking-[0.3em]">
              {year.name}
            </div>
            {year.semesters.map((sem: any) => (
              <div key={sem.name} className="mb-6 last:mb-0">
                <div className="text-center py-1.5 font-bold uppercase text-[11px] bg-neutral-100 border-x border-b border-black mb-1 tracking-widest italic">
                  {sem.name}
                </div>
                <table className="w-full border-collapse border border-black table-fixed">
                  <thead>
                    <tr className="bg-neutral-50 text-[8px] font-bold uppercase">
                      <th className="border border-black px-1 py-1 w-[8%]">Yr/Sem</th>
                      <th className="border border-black px-1 py-1 w-[8%]">Rating</th>
                      <th className="border border-black px-1 py-1 w-[12%]">Course Code</th>
                      <th className="border border-black px-2 py-1 text-left w-[36%]">Description</th>
                      <th className="border border-black px-1 py-1 w-[6%]">Lec</th>
                      <th className="border border-black px-1 py-1 w-[6%]">Lab</th>
                      <th className="border border-black px-1 py-1 w-[6%]">Units</th>
                      <th className="border border-black px-1 py-1 w-[18%]">Prerequisite</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sem.courses.map((course: any, idx: number) => {
                      const status = getGradeStatus(course, allFlattenedCourses);
                      const isRes = status === 'restricted';
                      return (
                        <tr key={idx} className={`text-[10px] h-7 ${isRes ? 'opacity-50 italic text-orange-700 bg-orange-50/20' : ''}`}>
                          <td className="border border-black text-center font-mono">{isRes ? 'RES' : (course.yrSemTaken || '---')}</td>
                          <td className={`border border-black text-center font-bold text-[12px] ${status === 'passed' ? 'text-blue-700' : status === 'failed' ? 'text-red-700' : ''}`}>
                            {isRes ? 'RES' : (course.gradeRating || '---')}
                          </td>
                          <td className="border border-black text-center font-bold">{course.courseCode}</td>
                          <td className="border border-black px-2 truncate">{course.courseDescription}</td>
                          <td className="border border-black text-center">{course.lectureHours}</td>
                          <td className="border border-black text-center">{course.labHours}</td>
                          <td className="border border-black text-center font-bold">{course.totalCreditUnits}</td>
                          <td className="border border-black text-center text-[8px]">{course.prerequisite || 'None'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                <div className="flex justify-between mt-2 px-1 text-[10px]">
                  <p><span className="font-bold">Semester GWA:</span> <span className="font-bold text-[12px] ml-1">{calculateGWA(sem.courses)}</span></p>
                  <p className="font-bold italic">Status: {calculateGWA(sem.courses) === '---' ? 'PENDING' : 'OFFICIALLY EVALUATED'}</p>
                </div>
              </div>
            ))}
          </div>
        ))}

        <div className="mt-10 pt-6 border-t-2 border-black grid grid-cols-2 gap-10">
          <div>
            <h4 className="font-bold uppercase text-[11px] border-b border-black mb-3 pb-1">Unit Summary</h4>
            <div className="space-y-1 text-[10px]">
              <div className="flex justify-between"><span>GE Subjects:</span> <span className="font-bold">{prospectusData.summaryOfUnits.generalEducation}</span></div>
              <div className="flex justify-between"><span>Professional:</span> <span className="font-bold">{prospectusData.summaryOfUnits.professionalCourses}</span></div>
              <div className="flex justify-between"><span>Major:</span> <span className="font-bold">{prospectusData.summaryOfUnits.majorCourses}</span></div>
              <div className="flex justify-between border-t border-black pt-1 font-bold"><span>TOTAL REQUIRED:</span> <span>{prospectusData.summaryOfUnits.generalEducation + prospectusData.summaryOfUnits.professionalCourses + prospectusData.summaryOfUnits.majorCourses}</span></div>
            </div>
          </div>
          <div className="text-center flex flex-col justify-center items-center border border-black/10 bg-neutral-50 p-4 rounded">
            <p className="font-bold text-[12px]">OJT REQUIREMENT</p>
            <p className="text-2xl font-black text-primary my-1">{prospectusData.ojtSection.hours} HOURS</p>
            <p className="text-[8px] italic uppercase">Verified by Department Head</p>
          </div>
        </div>

        <div className="mt-12 text-center text-[9px] text-neutral-400 italic">
          This is an automated academic evaluation generated by the CSU Student Profiling System.<br/>
          Evaluated by: {prospectusData.programAdviserName || 'Department Adviser'} on {prospectusData.dateEvaluated}
        </div>
      </div>
    </div>
  );
}