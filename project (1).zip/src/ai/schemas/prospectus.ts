import { z } from 'zod';

export const CourseSchema = z.object({
  yrSemTaken: z.string().optional().describe('Year or Semester when the course was actually taken.'),
  courseCode: z.string().describe('The code of the course, e.g., MATH1E.'),
  universityCode: z.string().describe('The university-specific code.'),
  courseDescription: z.string().describe('The full title of the course.'),
  lectureHours: z.number().describe('Number of lecture hours.'),
  labHours: z.number().describe('Number of lab, field, or drafting hours.'),
  totalCreditUnits: z.number().describe('Total credit units.'),
  prerequisite: z.string().nullable().describe('Prerequisite course(s).'),
  gradeRating: z.string().describe("The student's grade/rating."),
});

export const SemesterSchema = z.object({
  name: z.string().describe('Semester name.'),
  courses: z.array(CourseSchema).describe('List of courses.'),
  programAdviserName: z.string().describe('The adviser for this specific semester.'),
  dateEvaluated: z.string().describe('The evaluation date for this specific semester.'),
});

export const YearLevelSchema = z.object({
  name: z.string().describe('Academic year level.'),
  semesters: z.array(SemesterSchema).describe('List of semesters.'),
});

// Flat schema for AI to avoid nesting depth errors
export const FlatCourseSchema = CourseSchema.extend({
  yearName: z.string().describe('Name of the year (e.g., FIRST YEAR)'),
  semesterName: z.string().describe('Name of the semester (e.g., First Semester)'),
});

export const StudentInfoSchema = z.object({
  name: z.string(),
  id: z.string(),
  permanentAddress: z.string(),
  temporaryAddress: z.string(),
  phone: z.string(),
  yearAdmitted: z.string(),
});

export const AutomatedProspectusCreationOutputSchema_Flat = z.object({
  courses: z.array(FlatCourseSchema).describe('Flat list of courses with year and semester mapping.'),
  studentInfo: StudentInfoSchema.optional(),
  ojtSection: z.object({
    hours: z.number().describe('Required OJT hours.'),
  }),
  summaryOfUnits: z.object({
    generalEducation: z.number(),
    professionalCourses: z.number(),
    majorCourses: z.number(),
    totalUnits: z.number(),
  }),
  programAdviserName: z.string(),
  dateEvaluated: z.string(),
});

export const AutomatedProspectusCreationOutputSchema = z.object({
  studentInfo: StudentInfoSchema,
  academicProspectus: z.array(YearLevelSchema).describe('The structured academic prospectus.'),
  ojtSection: z.object({
    hours: z.number().describe('Required OJT hours.'),
  }),
  summaryOfUnits: z.object({
    generalEducation: z.number(),
    professionalCourses: z.number(),
    majorCourses: z.number(),
    totalUnits: z.number(),
  }),
});

export const AutomatedProspectusCreationInputSchema = z.object({
  programId: z.string(),
  studentId: z.string(),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
});

export type AutomatedProspectusCreationOutput = z.infer<typeof AutomatedProspectusCreationOutputSchema>;
export type AutomatedProspectusCreationInput = z.infer<typeof AutomatedProspectusCreationInputSchema>;
export type StudentInfo = z.infer<typeof StudentInfoSchema>;
