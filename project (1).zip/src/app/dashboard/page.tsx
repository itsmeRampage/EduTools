"use client";

import { useState, useMemo, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BookOpen, Plus, UserCircle, ChevronRight, Trash2, Loader2, LogOut, Users, Calendar, Clock, MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { 
  useUser, 
  useFirestore, 
  useCollection, 
  useMemoFirebase,
  setDocumentNonBlocking,
  deleteDocumentNonBlocking,
  useAuth
} from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import { signOut } from 'firebase/auth';

export default function ProfessorDashboard() {
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  
  const [newCourse, setNewCourse] = useState({ code: '', name: '' });
  const [isProgramOpen, setIsProgramOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("programs");

  // Schedule Form State
  const [isScheduleOpen, setIsScheduleOpen] = useState(false);
  const [scheduleForm, setScheduleForm] = useState({
    subjectCode: '',
    subjectName: '',
    instructor: '',
    day: 'Monday',
    startTime: '08:00',
    endTime: '10:00',
    room: '',
    maxStudents: '40'
  });

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/auth/login');
    }
  }, [user, isUserLoading, router]);

  const programsRef = useMemoFirebase(() => {
    if (isUserLoading || !user) return null;
    return collection(db, 'programs');
  }, [db, user, isUserLoading]);
  const { data: programs, isLoading: isProgramsLoading } = useCollection(programsRef);

  const schedulesRef = useMemoFirebase(() => {
    if (isUserLoading || !user) return null;
    return collection(db, 'schedules');
  }, [db, user, isUserLoading]);
  const { data: schedules, isLoading: isSchedulesLoading } = useCollection(schedulesRef);

  const studentsRef = useMemoFirebase(() => {
    if (isUserLoading || !user) return null;
    return collection(db, 'professors', user.uid, 'students');
  }, [db, user, isUserLoading]);
  const { data: students } = useCollection(studentsRef);

  const programStats = useMemo(() => {
    const stats: Record<string, { total: number; years: Record<string, number> }> = {};
    students?.forEach(student => {
      const pId = student.programId || 'unknown';
      const year = student.yearLevel || '1st Year';
      if (!stats[pId]) {
        stats[pId] = { total: 0, years: { '1st Year': 0, '2nd Year': 0, '3rd Year': 0, '4th Year': 0 } };
      }
      stats[pId].total++;
      if (stats[pId].years[year] !== undefined) stats[pId].years[year]++;
    });
    return stats;
  }, [students]);

  const handleAddCourse = () => {
    if (newCourse.code && newCourse.name && user) {
      const programId = newCourse.code.toLowerCase().replace(/\s+/g, '-');
      const programRef = doc(db, 'programs', programId);
      setDocumentNonBlocking(programRef, {
        id: programId,
        title: newCourse.name,
        code: newCourse.code,
        adviserProfessorId: user.uid,
      }, { merge: true });
      setNewCourse({ code: '', name: '' });
      setIsProgramOpen(false);
      toast({ title: "Program Added", description: `${newCourse.code} registered.` });
    }
  };

  const handleAddSchedule = () => {
    if (!user) return;
    const scheduleId = `sched-${Date.now()}`;
    const scheduleRef = doc(db, 'schedules', scheduleId);
    
    setDocumentNonBlocking(scheduleRef, {
      ...scheduleForm,
      id: scheduleId,
      maxStudents: parseInt(scheduleForm.maxStudents),
      enrolledCount: 0,
      createdAt: new Date().toISOString()
    }, { merge: true });

    setIsScheduleOpen(false);
    toast({ title: "Schedule Created", description: `Schedule for ${scheduleForm.subjectCode} saved.` });
    setScheduleForm({
      subjectCode: '',
      subjectName: '',
      instructor: user.displayName || 'Faculty Member',
      day: 'Monday',
      startTime: '08:00',
      endTime: '10:00',
      room: '',
      maxStudents: '40'
    });
  };

  const handleSignOut = async () => {
    await signOut(auth);
    router.push('/auth/login');
  };

  if (isUserLoading) return <div className="flex items-center justify-center min-h-screen"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  if (!user) return null;

  return (
    <div className="flex flex-col min-h-screen bg-neutral-50">
      <header className="h-16 border-b bg-white flex items-center px-6 justify-between sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-2">
          <BookOpen className="h-6 w-6 text-primary" />
          <h1 className="text-lg font-bold text-secondary uppercase tracking-tight">EDU Dashboard</h1>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={handleSignOut} className="hover:bg-red-50 hover:text-red-500 rounded-full">
            <LogOut className="h-5 w-5" />
          </Button>
          <UserCircle className="h-8 w-8 text-neutral-300" />
        </div>
      </header>

      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <div className="flex items-center justify-between">
            <TabsList className="bg-white border p-1 rounded-xl h-12">
              <TabsTrigger value="programs" className="rounded-lg font-black text-[10px] uppercase tracking-widest px-6 data-[state=active]:bg-primary data-[state=active]:text-white">Programs</TabsTrigger>
              <TabsTrigger value="schedules" className="rounded-lg font-black text-[10px] uppercase tracking-widest px-6 data-[state=active]:bg-primary data-[state=active]:text-white">Schedules</TabsTrigger>
            </TabsList>

            {activeTab === "programs" ? (
              <Dialog open={isProgramOpen} onOpenChange={setIsProgramOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary h-12 px-8 font-black text-[10px] uppercase tracking-widest rounded-xl shadow-lg">
                    <Plus className="h-4 w-4 mr-2" /> New Program
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Register Program</DialogTitle></DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">Code</Label>
                      <Input placeholder="BSCpE" value={newCourse.code} onChange={e => setNewCourse({...newCourse, code: e.target.value})} />
                    </div>
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">Full Title</Label>
                      <Input placeholder="BS in Computer Engineering" value={newCourse.name} onChange={e => setNewCourse({...newCourse, name: e.target.value})} />
                    </div>
                  </div>
                  <DialogFooter><Button onClick={handleAddCourse}>Create</Button></DialogFooter>
                </DialogContent>
              </Dialog>
            ) : (
              <Dialog open={isScheduleOpen} onOpenChange={setIsScheduleOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-secondary h-12 px-8 font-black text-[10px] uppercase tracking-widest rounded-xl shadow-lg">
                    <Calendar className="h-4 w-4 mr-2" /> Add Class Schedule
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader><DialogTitle>Create Class Schedule</DialogTitle></DialogHeader>
                  <div className="grid grid-cols-2 gap-4 py-4">
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">Subject Code</Label>
                      <Input placeholder="CS101" value={scheduleForm.subjectCode} onChange={e => setScheduleForm({...scheduleForm, subjectCode: e.target.value})} />
                    </div>
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">Subject Name</Label>
                      <Input placeholder="Intro to Programming" value={scheduleForm.subjectName} onChange={e => setScheduleForm({...scheduleForm, subjectName: e.target.value})} />
                    </div>
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">Instructor</Label>
                      <Input value={scheduleForm.instructor} onChange={e => setScheduleForm({...scheduleForm, instructor: e.target.value})} />
                    </div>
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">Day</Label>
                      <Select value={scheduleForm.day} onValueChange={val => setScheduleForm({...scheduleForm, day: val})}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"].map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">Start Time</Label>
                      <Input type="time" value={scheduleForm.startTime} onChange={e => setScheduleForm({...scheduleForm, startTime: e.target.value})} />
                    </div>
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">End Time</Label>
                      <Input type="time" value={scheduleForm.endTime} onChange={e => setScheduleForm({...scheduleForm, endTime: e.target.value})} />
                    </div>
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">Room</Label>
                      <Input placeholder="Lab 101" value={scheduleForm.room} onChange={e => setScheduleForm({...scheduleForm, room: e.target.value})} />
                    </div>
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-bold uppercase">Max Slots</Label>
                      <Input type="number" value={scheduleForm.maxStudents} onChange={e => setScheduleForm({...scheduleForm, maxStudents: e.target.value})} />
                    </div>
                  </div>
                  <DialogFooter><Button onClick={handleAddSchedule} className="bg-primary px-8">Save Schedule</Button></DialogFooter>
                </DialogContent>
              </Dialog>
            )}
          </div>

          <TabsContent value="programs">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {programs?.map((program) => {
                const stats = programStats[program.id] || { total: 0, years: { '1st Year': 0, '2nd Year': 0, '3rd Year': 0, '4th Year': 0 } };
                return (
                  <Card key={program.id} className="border-t-8 border-t-primary rounded-2xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
                    <CardHeader className="pb-4">
                      <div className="flex justify-between items-start">
                        <span className="text-[9px] font-black text-primary uppercase bg-primary/5 px-2 py-1 rounded">{program.code}</span>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-300 hover:text-red-500 rounded-full">
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="rounded-2xl">
                            <AlertDialogHeader>
                              <AlertDialogTitle className="text-xl font-black uppercase tracking-tight">Remove Program?</AlertDialogTitle>
                              <AlertDialogDescription className="font-medium">
                                Are you sure you want to delete <strong>{program.title}</strong>? This will remove the program from your dashboard.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter className="gap-2">
                              <AlertDialogCancel className="rounded-xl font-bold">Cancel</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => {
                                  deleteDocumentNonBlocking(doc(db, 'programs', program.id));
                                  toast({ title: "Program Removed", description: `The record for ${program.code} has been deleted.` });
                                }}
                                className="bg-red-600 text-white hover:bg-red-700 rounded-xl font-bold"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                      <CardTitle className="text-xl font-black mt-2 leading-tight">{program.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-2 gap-2">
                        {Object.entries(stats.years).map(([year, count]) => (
                          <div key={year} className="bg-neutral-50 p-2 rounded-lg text-center border">
                            <p className="text-[8px] font-bold text-muted-foreground uppercase">{year}</p>
                            <p className="text-lg font-black text-secondary">{count}</p>
                          </div>
                        ))}
                      </div>
                      <Link href={`/course/${program.id}`}>
                        <Button className="w-full rounded-xl bg-neutral-900 hover:bg-neutral-800 text-[10px] uppercase font-black tracking-widest h-11">
                          Manage Students <ChevronRight className="h-3 w-3 ml-2" />
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                );
              })}
              {programs?.length === 0 && (
                <div className="col-span-full py-24 text-center border-2 border-dashed rounded-[2rem] bg-white">
                  <BookOpen className="h-12 w-12 text-neutral-200 mx-auto mb-4" />
                  <p className="text-sm font-black text-muted-foreground uppercase tracking-widest">No programs registered yet</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="schedules">
            <div className="bg-white border rounded-2xl overflow-hidden shadow-sm">
              <table className="w-full text-left">
                <thead className="bg-neutral-50 border-b">
                  <tr>
                    <th className="px-6 py-4 text-[10px] font-black uppercase text-muted-foreground">Subject</th>
                    <th className="px-6 py-4 text-[10px] font-black uppercase text-muted-foreground">Schedule</th>
                    <th className="px-6 py-4 text-[10px] font-black uppercase text-muted-foreground">Room</th>
                    <th className="px-6 py-4 text-[10px] font-black uppercase text-muted-foreground">Slots</th>
                    <th className="px-6 py-4 text-right"></th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {schedules?.map((sched) => (
                    <tr key={sched.id} className="hover:bg-neutral-50 transition-colors">
                      <td className="px-6 py-4">
                        <p className="font-black text-secondary">{sched.subjectCode}</p>
                        <p className="text-xs text-muted-foreground">{sched.subjectName}</p>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-xs font-bold text-neutral-600">
                          <Calendar className="h-3 w-3" /> {sched.day}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                          <Clock className="h-3 w-3" /> {sched.startTime} - {sched.endTime}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-xs font-bold">
                          <MapPin className="h-3 w-3 text-primary" /> {sched.room}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-black">{sched.enrolledCount} / {sched.maxStudents}</span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <Button variant="ghost" size="icon" className="text-red-400 hover:text-red-600" onClick={() => deleteDocumentNonBlocking(doc(db, 'schedules', sched.id))}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {schedules?.length === 0 && (
                <div className="p-20 text-center">
                  <Calendar className="h-12 w-12 text-neutral-200 mx-auto mb-4" />
                  <p className="text-sm font-bold text-muted-foreground uppercase">No schedules created yet</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}