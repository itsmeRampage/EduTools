
"use client";

import { use, useEffect, useState, useMemo, Suspense, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent 
} from '@/components/ui/card';
import { 
  Printer, 
  GraduationCap,
  Loader2,
  LogOut,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Calendar,
  BookOpen,
  Clock,
  MapPin,
  Camera,
  Save,
  User,
  Info
} from 'lucide-react';
import { 
  useFirestore, 
  useDoc, 
  useCollection,
  useMemoFirebase,
  setDocumentNonBlocking,
  deleteDocumentNonBlocking,
  updateDocumentNonBlocking
} from '@/firebase';
import { doc, collection, query, where, increment } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import Image from 'next/image';

const formatTo12Hour = (time24: string) => {
  if (!time24) return '';
  const [hour, minute] = time24.split(':');
  const h = parseInt(hour);
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${minute} ${ampm}`;
};

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const TIME_SLOTS = Array.from({ length: 29 }, (_, i) => {
  const totalMinutes = 7 * 60 + i * 30;
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
});

function StudentPortalContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const db = useFirestore();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const profId = searchParams.get('prof');
  const studentId = searchParams.get('sid');

  const [session, setSession] = useState<{ studentId: string; profId: string } | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("prospectus");
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  // Local Editable State
  const [localStudentInfo, setLocalStudentInfo] = useState({
    name: "",
    permanentAddress: "",
    phone: "",
    id: ""
  });
  const [localPhotoUrl, setLocalPhotoUrl] = useState("");

  useEffect(() => {
    const savedSession = sessionStorage.getItem('student_portal_session');
    
    if (!savedSession) {
      if (profId) {
        router.push(`/student-portal/login?prof=${profId}`);
      } else {
        router.push('/student-portal/login');
      }
      return;
    }

    try {
      const parsed = JSON.parse(savedSession);
      
      if (profId && studentId) {
        if (parsed.studentId !== studentId || parsed.profId !== profId) {
          router.push(`/student-portal/login?prof=${profId}`);
          return;
        }
      }

      setSession(parsed);
    } catch (e) {
      router.push('/student-portal/login');
    } finally {
      setIsAuthLoading(false);
    }
  }, [profId, studentId, router]);

  const studentDocRef = useMemoFirebase(() => {
    if (!profId || !studentId) return null;
    return doc(db, 'professors', profId, 'students', studentId);
  }, [db, profId, studentId]);
  
  const { data: record, isLoading: isDocLoading } = useDoc(studentDocRef);

  useEffect(() => {
    if (record && record.prospectusData) {
      setLocalStudentInfo({
        name: record.prospectusData.studentInfo?.name || "",
        permanentAddress: record.prospectusData.studentInfo?.permanentAddress || "",
        phone: record.prospectusData.studentInfo?.phone || "",
        id: record.prospectusData.studentInfo?.id || studentId || ""
      });
      setLocalPhotoUrl(record.photoUrl || "");
    }
  }, [record, studentId]);

  const schedulesRef = useMemoFirebase(() => collection(db, 'schedules'), [db]);
  const { data: schedules } = useCollection(schedulesRef);

  const enrollmentsQuery = useMemoFirebase(() => {
    if (!studentId) return null;
    return query(collection(db, 'enrollments'), where('studentId', '==', studentId));
  }, [db, studentId]);
  const { data: enrollments } = useCollection(enrollmentsQuery);

  const enrolledSchedules = useMemo(() => {
    if (!enrollments || !schedules) return [];
    const scheduleIds = enrollments.map(e => e.scheduleId);
    return schedules.filter(s => scheduleIds.includes(s.id));
  }, [enrollments, schedules]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setLocalPhotoUrl(reader.result as string);
        toast({ title: "Photo Updated", description: "Remember to save your profile changes." });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = async () => {
    if (!profId || !studentId || !record) return;
    setIsSavingProfile(true);

    try {
      const profStudentRef = doc(db, 'professors', profId, 'students', studentId);
      const globalRef = doc(db, 'students', studentId);

      const updatedProspectus = {
        ...record.prospectusData,
        studentInfo: {
          ...record.prospectusData.studentInfo,
          name: localStudentInfo.name,
          permanentAddress: localStudentInfo.permanentAddress,
          phone: localStudentInfo.phone
        }
      };

      const payload = {
        prospectusData: updatedProspectus,
        photoUrl: localPhotoUrl,
        lastUpdated: new Date().toISOString(),
        firstName: localStudentInfo.name.split(',')[1]?.trim() || record.firstName,
        lastName: localStudentInfo.name.split(',')[0]?.trim() || record.lastName
      };

      updateDocumentNonBlocking(profStudentRef, payload);
      updateDocumentNonBlocking(globalRef, {
        photoUrl: localPhotoUrl,
        firstName: payload.firstName,
        lastName: payload.lastName,
        lastSynced: new Date().toISOString()
      });

      toast({ title: "Profile Updated", description: "Your personal information has been saved successfully." });
    } catch (err) {
      toast({ variant: "destructive", title: "Update Failed", description: "Could not save changes." });
    } finally {
      setIsSavingProfile(false);
    }
  };

  const calculateGWA = (courses: any[]) => {
    if (!courses || courses.length === 0) return '---';
    let totalQualityPoints = 0;
    let totalUnits = 0;
    courses.forEach(c => {
      const grade = parseFloat(c.gradeRating);
      const units = parseFloat(c.totalCreditUnits);
      if (!isNaN(grade) && grade > 0 && !isNaN(units)) {
        totalQualityPoints += (grade * units);
        totalUnits += units;
      }
    });
    return totalUnits === 0 ? '---' : (totalQualityPoints / totalUnits).toFixed(2);
  };

  if (isAuthLoading || isDocLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!record || !record.prospectusData) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen text-center p-6">
        <AlertCircle className="h-12 w-12 text-muted-foreground mb-4 opacity-20" />
        <h2 className="text-xl font-black uppercase">Official Record Missing</h2>
        <p className="text-muted-foreground mt-2 max-w-md">Your evaluation record hasn't been officially published by your professor yet.</p>
        <Button className="mt-6 rounded-xl" onClick={() => router.push('/')}>Return Home</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-100 p-4 md:p-8">
      <header className="max-w-[1200px] mx-auto flex items-center justify-between mb-8 px-4 md:px-0">
        <div className="flex items-center gap-4">
          <GraduationCap className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-xl font-black uppercase tracking-tight text-secondary">
              {localStudentInfo.name || 'STUDENT'}
            </h1>
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
              {studentId} • Academic Portal
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button size="sm" className="h-9 rounded-xl bg-primary px-6 font-bold text-[10px] uppercase tracking-widest" onClick={handleSaveProfile} disabled={isSavingProfile}>
            {isSavingProfile ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-2" /> : <Save className="h-3.5 w-3.5 mr-2" />}
            Save Profile
          </Button>
          <Button variant="ghost" size="sm" className="font-bold text-red-500 hover:bg-red-50" onClick={() => { sessionStorage.removeItem('student_portal_session'); router.push(`/student-portal/login?prof=${profId || ''}`); }}>
            <LogOut className="h-4 w-4 mr-2" /> Logout
          </Button>
        </div>
      </header>

      <main className="max-w-[1200px] mx-auto space-y-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-white border p-1 h-14 rounded-2xl shadow-sm w-full md:w-auto">
            <TabsTrigger value="prospectus" className="rounded-xl px-8 font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white h-full">Prospectus</TabsTrigger>
            <TabsTrigger value="enrollment" className="rounded-xl px-8 font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white h-full">Enrollment</TabsTrigger>
            <TabsTrigger value="schedule" className="rounded-xl px-8 font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white h-full">Timetable</TabsTrigger>
          </TabsList>

          <TabsContent value="prospectus">
            {/* ... Prospectus Content remains same as previous ... */}
            <div className="bg-white border border-neutral-300 rounded-3xl p-10 shadow-xl min-h-[1000px] text-black font-serif text-[11px] leading-tight overflow-hidden transition-all print:p-0 print:border-none print:shadow-none">
              <div className="relative flex flex-col items-center mb-8">
                <div className="text-center space-y-0.5 mt-2 w-full max-w-[600px]">
                  <p className="w-full text-center text-[10px] uppercase font-medium tracking-wide">{record.headerData?.republic || "Republic of the Philippines"}</p>
                  <p className="w-full text-center text-[16px] font-bold uppercase tracking-widest text-neutral-900">{record.headerData?.university || "UNIVERSITY PORTAL"}</p>
                  <p className="w-full text-center text-[11px] font-medium">{record.headerData?.location || "Academic Records Division"}</p>
                  <div className="h-0.5 w-40 bg-black/10 mx-auto my-2" />
                  <p className="w-full text-center text-[12px] uppercase font-bold text-neutral-800">{record.headerData?.college || "College Department"}</p>
                </div>
                
                <div 
                  className="absolute right-0 top-0 border-[1.5px] border-black/80 w-28 h-28 flex items-center justify-center text-center p-0 leading-none bg-neutral-50/50 overflow-hidden cursor-pointer group no-print"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {localPhotoUrl ? (
                    <img src={localPhotoUrl} alt="2x2 ID" className="w-full h-full object-cover" />
                  ) : (
                    <div className="flex flex-col items-center gap-1">
                      <Camera className="h-6 w-6 text-neutral-300 group-hover:text-primary transition-colors" />
                      <span className="font-bold text-[8px] text-neutral-400">UPLOAD PHOTO</span>
                    </div>
                  )}
                  <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
                </div>
                <div className="hidden print:block absolute right-0 top-0 border-[1.5px] border-black/80 w-28 h-28 overflow-hidden">
                   {localPhotoUrl ? <img src={localPhotoUrl} alt="ID" className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-[8px] text-neutral-300">2x2 PHOTO</div>}
                </div>
              </div>

              <div className="text-center mb-6">
                <p className="text-[14px] font-bold uppercase tracking-widest border-b-[1.5px] border-black inline-block pb-0.5">OFFICIAL PROSPECTUS EVALUATION</p>
                <div className="mt-3">
                  <p className="text-[13px] font-bold uppercase text-neutral-900">{record.headerData?.degree || "Degree Program Title"}</p>
                </div>
              </div>

              <div className="grid grid-cols-12 gap-x-4 gap-y-2 mt-6 mb-8 border-t-2 border-black pt-4">
                <div className="col-span-8 flex border-b border-black pb-0.5">
                  <span className="font-bold min-w-[50px] text-[10px] uppercase">Name:</span>
                  <input className="flex-1 px-2 uppercase font-bold text-[12px] bg-transparent outline-none border-none" value={localStudentInfo.name} onChange={(e) => setLocalStudentInfo({...localStudentInfo, name: e.target.value})} />
                </div>
                <div className="col-span-4 flex border-b border-black pb-0.5 items-end">
                  <span className="font-bold min-w-[90px] text-[10px] uppercase">Student I.D No.:</span>
                  <span className="flex-1 px-2 font-mono font-bold text-neutral-800 tracking-wider">{localStudentInfo.id}</span>
                </div>
              </div>

              {record.prospectusData.academicProspectus?.map((year: any) => (
                <div key={year.name} className="mb-10 break-inside-avoid">
                  <div className="bg-neutral-900 text-white py-1.5 text-center border border-black mb-1 font-bold text-[13px] uppercase tracking-[0.3em]">{year.name}</div>
                  {year.semesters?.map((sem: any) => (
                    <div key={sem.name} className="mb-6 last:mb-0">
                      <div className="text-center py-1.5 font-bold uppercase text-[11px] bg-neutral-100 border-x border-b border-black mb-1 tracking-widest italic">{sem.name}</div>
                      <table className="w-full border-collapse border border-black text-[10px] table-fixed">
                        <thead><tr className="bg-neutral-50 uppercase text-[8px]"><th className="border border-black p-2 w-[10%]">Rating</th><th className="border border-black p-2 w-[15%]">Code</th><th className="border border-black p-2 text-left w-[45%]">Description</th><th className="border border-black p-2 w-[10%]">Units</th><th className="border border-black p-2 w-[20%]">Status</th></tr></thead>
                        <tbody>{sem.courses?.map((c: any, idx: number) => (<tr key={idx} className="h-7"><td className="border border-black text-center font-bold text-[12px]">{c.gradeRating || '---'}</td><td className="border border-black text-center font-bold">{c.courseCode || '---'}</td><td className="border border-black px-2 truncate">{c.courseDescription || '---'}</td><td className="border border-black text-center font-bold">{c.totalCreditUnits || '0'}</td><td className="border border-black text-center">{parseFloat(c.gradeRating) <= 3.0 ? <span className="text-blue-600 uppercase font-black text-[8px]">Passed</span> : <span className="text-neutral-400 text-[8px] uppercase font-bold">Pending</span>}</td></tr>))}</tbody>
                      </table>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="enrollment">
            {/* ... Enrollment Content remains same ... */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <Card className="rounded-3xl border-none shadow-xl overflow-hidden">
                  <CardHeader className="bg-primary text-white p-8">
                    <CardTitle className="text-2xl font-black uppercase tracking-tight">Open Enrollment</CardTitle>
                    <CardDescription className="text-primary-foreground/70 font-medium italic">Available subjects for the current term.</CardDescription>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="divide-y">
                      {schedules?.map((sched) => {
                        const isEnrolled = enrollments?.some(e => e.scheduleId === sched.id);
                        return (
                          <div key={sched.id} className="p-6 flex items-center justify-between hover:bg-neutral-50 transition-colors">
                            <div className="space-y-1">
                              <h4 className="text-lg font-black text-secondary">{sched.subjectCode}</h4>
                              <p className="text-sm font-bold text-muted-foreground">{sched.subjectName}</p>
                              <div className="flex gap-4 mt-2">
                                <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-500"><Calendar className="h-3.5 w-3.5" /> {sched.day}</div>
                                <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-500"><Clock className="h-3.5 w-3.5" /> {formatTo12Hour(sched.startTime)} - {formatTo12Hour(sched.endTime)}</div>
                                <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-500"><MapPin className="h-3.5 w-3.5" /> {sched.room}</div>
                              </div>
                            </div>
                            <Button className="rounded-xl font-black text-[10px] uppercase" variant={isEnrolled ? "outline" : "default"} disabled={sched.enrolledCount >= (sched.maxStudents || 0) && !isEnrolled}>
                              {isEnrolled ? "Enrolled" : "Enroll"}
                            </Button>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="schedule">
            <Card className="rounded-[2rem] shadow-2xl overflow-hidden bg-white border-none">
              <div className="p-10 border-b bg-neutral-900 text-white flex justify-between items-center">
                <div>
                  <h2 className="text-3xl font-black uppercase tracking-tighter">Academic Timetable</h2>
                  <p className="text-xs font-bold text-neutral-400 uppercase tracking-widest mt-1">12-Hour Accurate Schedule</p>
                </div>
                <Button variant="outline" size="sm" className="bg-white/10 border-white/20 text-white hover:bg-white/20" onClick={() => window.print()}>
                  <Printer className="h-4 w-4 mr-2" /> Print
                </Button>
              </div>
              <div className="p-8 overflow-x-auto">
                <div className="min-w-[800px]">
                  <div className="grid grid-cols-7 border-b-2 border-neutral-200 bg-neutral-50 sticky top-0">
                    <div className="p-4 border-r text-[9px] font-black uppercase tracking-widest text-muted-foreground flex items-center justify-center">Time</div>
                    {DAYS.map(day => (
                      <div key={day} className="p-4 text-center font-black uppercase text-[10px] tracking-widest text-secondary border-r last:border-0">{day}</div>
                    ))}
                  </div>
                  {TIME_SLOTS.map((slot) => (
                    <div key={slot} className="grid grid-cols-7 border-b border-neutral-100 min-h-[50px]">
                      <div className="p-2 border-r bg-neutral-50/50 flex items-center justify-center text-[9px] font-mono font-bold text-muted-foreground">
                        {formatTo12Hour(slot)}
                      </div>
                      {DAYS.map(day => {
                        const schedAtStart = enrolledSchedules.find(s => s.day === day && s.startTime === slot);
                        const isOccupied = enrolledSchedules.some(s => s.day === day && slot >= s.startTime && slot < s.endTime);
                        return (
                          <div key={`${day}-${slot}`} className={cn("p-0.5 border-r last:border-0 relative", isOccupied ? "bg-primary/5" : "")}>
                            {schedAtStart && (
                              <div className="absolute inset-x-1 top-1 bg-secondary text-white p-2.5 rounded-xl shadow-lg z-10 overflow-hidden flex flex-col justify-center border-l-4 border-primary">
                                <p className="text-[10px] font-black uppercase truncate">{schedAtStart.subjectCode}</p>
                                <p className="text-[8px] font-bold opacity-80 uppercase line-clamp-1">{schedAtStart.subjectName}</p>
                                <div className="mt-1 flex items-center gap-1 opacity-70">
                                  <Clock className="h-2.5 w-2.5" />
                                  <span className="text-[7px] font-black uppercase">{formatTo12Hour(schedAtStart.startTime)}</span>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

export default function StudentPortalView() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center min-h-screen"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>}>
      <StudentPortalContent />
    </Suspense>
  );
}
