export const firebaseConfig = {
  "projectId": "studio-4144227073-47fa3",
  "appId": "1:348913955207:web:2b6ac4bda870e053ce6322",
  "apiKey": "AIzaSyDv8Agb0hUifrmdy_DpFJGrnN6CvZPT0-E",
  "authDomain": "studio-4144227073-47fa3.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "348913955207"
};
