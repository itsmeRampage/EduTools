# Step-by-Step GitHub Upload Guide for EduTools

Since you have already created your repository at `https://github.com/itsmeRampage/EduTools.git`, follow these steps to get your code online.

## Method 1: The Easiest Way (No Terminal)
1. Open your repository in your browser: [https://github.com/itsmeRampage/EduTools](https://github.com/itsmeRampage/EduTools)
2. Click the **"Add file"** button (top right) and select **"Upload files"**.
3. **Drag and Drop** all the files and folders from your computer into the box on the screen.
4. Wait for the progress bar to finish.
5. Scroll down and click the green **"Commit changes"** button.

---

## Method 2: Using the Terminal (Copy & Paste)
If you want to use the terminal in this editor, copy and paste these commands one by one:

```bash
# 1. Initialize the folder
git init

# 2. Add all your files
git add .

# 3. Create a save point
git commit -m "Launch EDUProfile"

# 4. Set the branch
git branch -M main

# 5. Connect to your specific repository
git remote add origin https://github.com/itsmeRampage/EduTools.git

# 6. Upload (It will ask for your GitHub login)
git push -u origin main
```

---

### What's next?
Once your files appear on GitHub, open the `DEPLOYMENT_GUIDE.md` file in your project to connect it to **Vercel** for free hosting (No credit card needed).
