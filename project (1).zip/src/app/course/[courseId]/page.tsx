"use client";

import { useState, use, useMemo, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { 
  ArrowLeft, 
  Plus, 
  Search, 
  GraduationCap, 
  Loader2, 
  Users, 
  ChevronRight, 
  Trash2, 
  FileSpreadsheet, 
  Upload,
  AlertCircle,
  FileText
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { 
  useUser, 
  useFirestore, 
  useCollection, 
  useMemoFirebase,
  setDocumentNonBlocking,
  deleteDocumentNonBlocking
} from '@/firebase';
import { collection, doc } from 'firebase/firestore';
import { automatedProspectusCreation } from '@/ai/flows/automated-prospectus-creation';
import * as XLSX from 'xlsx';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

export default function CourseStudents({ params }: { params: Promise<{ courseId: string }> }) {
  const { courseId } = use(params);
  const { user, isUserLoading } = useUser();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [isBatchProcessing, setIsBatchProcessing] = useState(false);
  const [batchProgress, setBatchProgress] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [isBatchOpen, setIsBatchOpen] = useState(false);
  const [selectedYear, setSelectedYear] = useState<string | null>(null);
  const [newStudent, setNewStudent] = useState({ id: '', firstName: '', lastName: '', yearLevel: '1st Year' });

  // Guarded auth check
  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push('/auth/login');
    }
  }, [user, isUserLoading, router]);

  // Sync manual enrollment default year with selectedYear
  useEffect(() => {
    if (selectedYear) {
      setNewStudent(prev => ({ ...prev, yearLevel: selectedYear }));
    }
  }, [selectedYear]);

  // Real-time student data
  const studentsRef = useMemoFirebase(() => {
    if (isUserLoading || !user) return null;
    return collection(db, 'professors', user.uid, 'students');
  }, [db, user, isUserLoading]);
  
  const { data: allStudents, isLoading: isStudentsLoading } = useCollection(studentsRef);

  const groupedStudents = useMemo(() => {
    if (!allStudents) return {};
    const filtered = allStudents.filter(s => 
      s.programId === courseId &&
      (
        s.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) || 
        s.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) || 
        s.id?.includes(searchTerm)
      )
    );
    const groups: Record<string, typeof allStudents> = {
      '1st Year': [],
      '2nd Year': [],
      '3rd Year': [],
      '4th Year': [],
    };
    filtered.forEach(student => {
      const level = student.yearLevel || '1st Year';
      if (groups[level]) {
        groups[level].push(student);
      }
    });
    Object.keys(groups).forEach(level => {
      groups[level].sort((a, b) => {
        const surnameA = (a.lastName || '').trim().toLowerCase();
        const surnameB = (b.lastName || '').trim().toLowerCase();
        return surnameA.localeCompare(surnameB);
      });
    });
    return groups;
  }, [allStudents, courseId, searchTerm]);

  const statsSummary = useMemo(() => {
    const counts = { total: 0, levels: {} as Record<string, number> };
    Object.entries(groupedStudents).forEach(([level, students]) => {
      counts.levels[level] = students.length;
      counts.total += students.length;
    });
    return counts;
  }, [groupedStudents]);

  const enrollStudent = async (student: { id: string, firstName: string, lastName: string, yearLevel: string }) => {
    if (!user) return;
    const trimmedId = student.id.toString().trim();
    const initialProspectus = await automatedProspectusCreation({
      programId: courseId,
      studentId: trimmedId,
      firstName: student.firstName,
      lastName: student.lastName
    });

    const studentRef = doc(db, 'professors', user.uid, 'students', trimmedId);
    const globalRef = doc(db, 'students', trimmedId);
    
    const studentData = {
      id: trimmedId,
      firstName: student.firstName.trim(),
      lastName: student.lastName.trim(),
      yearLevel: student.yearLevel,
      programId: courseId,
      managingProfessorId: user.uid,
      email: `${trimmedId}@csu.edu.ph`,
      yearAdmitted: new Date().getFullYear(),
      dateEvaluated: "", 
      prospectusData: initialProspectus,
      photoUrl: "" 
    };

    setDocumentNonBlocking(studentRef, studentData, { merge: true });
    setDocumentNonBlocking(globalRef, {
      id: trimmedId,
      managingProfessorId: user.uid,
      firstName: student.firstName.trim(),
      lastName: student.lastName.trim(),
      photoUrl: ""
    }, { merge: true });
  };

  const handleEnroll = async () => {
    const trimmedId = newStudent.id.trim();
    if (trimmedId && newStudent.firstName && newStudent.lastName && user) {
      setIsEnrolling(true);
      try {
        await enrollStudent({
          id: trimmedId,
          firstName: newStudent.firstName,
          lastName: newStudent.lastName,
          yearLevel: newStudent.yearLevel
        });
        toast({ title: "Student Enrolled", description: `${newStudent.lastName.toUpperCase()}, ${newStudent.firstName} added to ${newStudent.yearLevel}.` });
        setNewStudent({ id: '', firstName: '', lastName: '', yearLevel: selectedYear || '1st Year' });
        setIsOpen(false);
      } catch (error) {
        toast({ variant: "destructive", title: "Enrollment Error", description: "Failed to generate record." });
      } finally {
        setIsEnrolling(false);
      }
    }
  };

  const getFuzzyValue = (row: any, aliases: string[]) => {
    const normalize = (s: string) => s.toLowerCase().replace(/[\s_-]/g, '');
    const normalizedAliases = aliases.map(normalize);
    for (const key of Object.keys(row)) {
      if (normalizedAliases.includes(normalize(key))) return row[key];
    }
    return undefined;
  };

  const handleExcelUpload = (e: React.ChangeEvent<HTMLInputElement> | { target: { files: FileList | null } }) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws) as any[];
        if (data.length === 0) return;

        setIsBatchProcessing(true);
        setBatchProgress(0);
        let successCount = 0;

        for (let i = 0; i < data.length; i++) {
          const row = data[i];
          const sid = getFuzzyValue(row, ['Student ID', 'ID', 'studentId', 'Student Number', 'No', 'Number']);
          let fname = getFuzzyValue(row, ['First Name', 'Firstname', 'firstName', 'Given Name', 'GivenName']);
          let lname = getFuzzyValue(row, ['Last Name', 'Surname', 'lastName', 'LastName', 'Family Name', 'FamilyName']);
          const fullName = getFuzzyValue(row, ['Full Name', 'Name', 'Student Name', 'StudentName']);

          if ((!fname || !lname) && fullName) {
            const nameStr = String(fullName).trim();
            if (nameStr.includes(',')) {
              const parts = nameStr.split(',');
              lname = parts[0].trim();
              fname = parts[1].trim();
            } else {
              const parts = nameStr.split(' ');
              fname = parts[0];
              lname = parts.slice(1).join(' ');
            }
          }

          const rawYear = getFuzzyValue(row, ['Year Level', 'Year', 'yearLevel', 'Level']);
          let ylevel = selectedYear || '1st Year';
          if (rawYear) {
            const ystr = String(rawYear);
            if (ystr.match(/1|first|1st/i)) ylevel = '1st Year';
            else if (ystr.match(/2|second|2nd/i)) ylevel = '2nd Year';
            else if (ystr.match(/3|third|3rd/i)) ylevel = '3rd Year';
            else if (ystr.match(/4|fourth|4th/i)) ylevel = '4th Year';
          }

          if (sid !== undefined && fname && lname) {
            try {
              await enrollStudent({ id: String(sid).trim(), firstName: String(fname).trim(), lastName: String(lname).trim(), yearLevel: ylevel });
              successCount++;
            } catch (err) {}
          }
          setBatchProgress(Math.round(((i + 1) / data.length) * 100));
        }

        toast({ title: "Batch Complete", description: `Successfully enrolled ${successCount} students.` });
      } catch (err) {} finally {
        setIsBatchProcessing(false);
        setIsBatchOpen(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleRemoveStudent = (sid: string, name: string) => {
    if (!user) return;
    deleteDocumentNonBlocking(doc(db, 'professors', user.uid, 'students', sid));
    deleteDocumentNonBlocking(doc(db, 'students', sid));
    toast({ title: "Student Removed", description: `${name} removed from roster.` });
  };

  if (isUserLoading || isStudentsLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-neutral-50 space-y-4">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
        <p className="text-[10px] font-black uppercase tracking-widest text-neutral-400">Syncing Roster...</p>
      </div>
    );
  }

  if (!user) return null;

  const selectedStudents = selectedYear ? groupedStudents[selectedYear] : [];

  return (
    <div className="flex flex-col min-h-screen bg-neutral-50">
      <header className="h-16 border-b bg-white flex items-center px-6 justify-between sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-4">
          {selectedYear ? (
            <Button variant="ghost" size="icon" className="rounded-full" onClick={() => setSelectedYear(null)}>
              <ArrowLeft className="h-5 w-5 text-secondary" />
            </Button>
          ) : (
            <Link href="/dashboard">
              <Button variant="ghost" size="icon" className="rounded-full">
                <ArrowLeft className="h-5 w-5 text-secondary" />
              </Button>
            </Link>
          )}
          <div className="flex items-center gap-2">
            <GraduationCap className="h-6 w-6 text-primary" />
            <h1 className="text-lg font-black text-secondary uppercase tracking-tight">
              {courseId} {selectedYear ? `- ${selectedYear}` : 'Directory'}
            </h1>
          </div>
        </div>
      </header>

      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        {!selectedYear && (
          <div className="bg-primary text-white p-6 rounded-3xl shadow-lg flex items-center justify-between mb-10 border-b-4 border-primary-foreground/20">
            <div>
              <span className="text-[10px] font-black uppercase tracking-[0.2em] opacity-80">PROGRAM ENROLLMENT</span>
              <h2 className="text-4xl font-black">{statsSummary.total} Students</h2>
            </div>
            <Users className="h-12 w-12 opacity-20" />
          </div>
        )}

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
          <div>
            <h2 className="text-3xl font-black text-secondary uppercase tracking-tight">
              {selectedYear ? `${selectedYear} List` : 'Select Year Level'}
            </h2>
          </div>

          {selectedYear && (
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  className="pl-11 h-12 w-[250px] bg-white rounded-xl shadow-sm" 
                  placeholder="Search by Surname..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              <Dialog open={isBatchOpen} onOpenChange={setIsBatchOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="h-12 px-6 font-black text-xs uppercase tracking-widest border-neutral-300 rounded-xl">
                    <FileSpreadsheet className="h-4 w-4 mr-2" />
                    Batch Enroll
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px] rounded-2xl">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-black uppercase tracking-tight">Excel Batch Enrollment</DialogTitle>
                    <DialogDescription>
                      Enrolling students directly into <strong>{selectedYear}</strong>. Headers should include <strong>ID</strong>, <strong>First Name</strong>, and <strong>Last Name</strong>.
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div 
                    className={cn(
                      "py-10 flex flex-col items-center justify-center border-2 border-dashed rounded-3xl transition-all cursor-pointer group relative overflow-hidden",
                      isDragging ? "border-primary bg-primary/5 scale-[0.98]" : "border-neutral-200 bg-neutral-50/50 hover:bg-neutral-50 hover:border-primary/50"
                    )}
                    onClick={() => !isBatchProcessing && fileInputRef.current?.click()}
                    onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={(e) => { e.preventDefault(); setIsDragging(false); handleExcelUpload({ target: { files: e.dataTransfer.files } }); }}
                  >
                    <div className="flex flex-col items-center text-center px-6">
                      {isBatchProcessing ? (
                        <Loader2 className="h-12 w-12 text-primary animate-spin mb-4" />
                      ) : (
                        <div className="relative mb-4">
                          <FileText className="h-14 w-14 text-neutral-300 group-hover:text-primary transition-colors" />
                          <div className="absolute -bottom-1 -right-1 bg-primary text-white p-1 rounded-full shadow-lg">
                            <Plus className="h-4 w-4" />
                          </div>
                        </div>
                      )}
                      <p className="text-sm font-black text-neutral-600 uppercase tracking-tight">
                        {isDragging ? "Drop to Process" : "Click or Drag Spreadsheet"}
                      </p>
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" accept=".xlsx, .xls, .csv" onChange={handleExcelUpload} />
                  </div>

                  {isBatchProcessing && (
                    <div className="space-y-4 pt-4">
                      <Progress value={batchProgress} className="h-2 rounded-full" />
                      <p className="text-[10px] font-black uppercase tracking-widest text-primary text-center">Syncing {batchProgress}%</p>
                    </div>
                  )}
                  <DialogFooter>
                    <Button variant="outline" className="rounded-xl font-bold" onClick={() => setIsBatchOpen(false)} disabled={isBatchProcessing}>Cancel</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
              
              <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-primary/90 h-12 px-8 font-black text-xs uppercase tracking-widest shadow-lg rounded-xl">
                    <Plus className="h-4 w-4 mr-2" />
                    Enroll Student
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[450px] rounded-2xl">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-black uppercase tracking-tight">Enroll Student</DialogTitle>
                    <DialogDescription>Add a new record to the {courseId} roster.</DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-6 py-4">
                    <div className="grid gap-2">
                      <Label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">I.D. Number</Label>
                      <Input placeholder="2024-00001" className="h-11" value={newStudent.id} onChange={(e) => setNewStudent({...newStudent, id: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">First Name</Label>
                        <Input placeholder="Given Name" className="h-11" value={newStudent.firstName} onChange={(e) => setNewStudent({...newStudent, firstName: e.target.value})} />
                      </div>
                      <div className="grid gap-2">
                        <Label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Surname</Label>
                        <Input placeholder="Family Name" className="h-11 font-bold" value={newStudent.lastName} onChange={(e) => setNewStudent({...newStudent, lastName: e.target.value})} />
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
                    <Button onClick={handleEnroll} disabled={isEnrolling} className="bg-primary h-11 rounded-xl px-8 font-bold">
                      {isEnrolling ? <Loader2 className="h-4 w-4 animate-spin" /> : "Enroll"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </div>

        {selectedYear ? (
          <div className="space-y-6">
            <Button variant="ghost" size="sm" className="text-xs font-black uppercase tracking-widest text-primary mb-4" onClick={() => setSelectedYear(null)}>
              <ArrowLeft className="h-3 w-3 mr-2" /> Back to Year Levels
            </Button>

            {selectedStudents.length > 0 ? (
              <section className="bg-white rounded-3xl border border-neutral-200 shadow-sm overflow-hidden">
                <Table>
                  <TableHeader className="bg-neutral-50">
                    <TableRow>
                      <TableHead className="w-[180px] text-[10px] font-black uppercase py-6 pl-8">Student I.D.</TableHead>
                      <TableHead className="text-[10px] font-black uppercase py-6">Name (SURNAME, First Name)</TableHead>
                      <TableHead className="w-[200px] text-right text-[10px] font-black uppercase py-6 pr-10">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {selectedStudents.map((student) => (
                      <TableRow key={student.id} className="hover:bg-neutral-50 border-b last:border-0">
                        <TableCell className="font-mono font-black text-xs text-primary pl-8">{student.id}</TableCell>
                        <TableCell className="py-5">
                          <span className="font-black text-neutral-900 uppercase text-base">{student.lastName}</span>
                          <span className="text-neutral-500 font-bold ml-2">, {student.firstName}</span>
                        </TableCell>
                        <TableCell className="text-right pr-10">
                          <div className="flex items-center justify-end gap-2">
                            <Link href={`/student/${student.id}`}>
                              <Button variant="outline" size="sm" className="h-10 font-black text-[10px] uppercase rounded-xl">EVALUATE</Button>
                            </Link>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-10 w-10 text-neutral-300 hover:text-red-600 rounded-xl"><Trash2 className="h-4 w-4" /></Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Remove Student?</AlertDialogTitle>
                                  <AlertDialogDescription>Permanently remove {student.lastName}, {student.firstName}?</AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction onClick={() => handleRemoveStudent(student.id, student.lastName)} className="bg-red-600 text-white">Remove</AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </section>
            ) : (
              <div className="text-center py-40 bg-white rounded-3xl border border-dashed border-neutral-300">
                <h3 className="text-2xl font-black text-secondary uppercase">No Students in {selectedYear}</h3>
                <Button variant="outline" className="mt-8 h-12 rounded-xl font-bold" onClick={() => setSelectedYear(null)}>Go Back</Button>
              </div>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Object.keys(groupedStudents).map((level) => (
              <button key={level} onClick={() => setSelectedYear(level)} className="bg-white border border-neutral-200 p-8 rounded-[2rem] shadow-sm flex flex-col items-center hover:shadow-xl hover:border-primary transition-all group">
                <div className="bg-primary/5 p-6 rounded-full mb-6 group-hover:bg-primary group-hover:text-white transition-colors">
                  <Users className="h-10 w-10 text-primary group-hover:text-white" />
                </div>
                <span className="text-[12px] font-black text-muted-foreground uppercase tracking-[0.3em] mb-2">{level}</span>
                <span className="text-4xl font-black text-secondary">{statsSummary.levels[level] || 0}</span>
                <div className="mt-8 flex items-center text-primary font-black text-[10px] uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                  View List <ChevronRight className="h-3 w-3 ml-1" />
                </div>
              </button>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
