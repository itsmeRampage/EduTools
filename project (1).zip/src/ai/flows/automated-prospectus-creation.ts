'use server';
/**
 * @fileOverview This file implements a simplified Genkit flow that generates a formal academic prospectus matching the CSU curriculum.
 * It ensures that student information like names are correctly pre-populated during the record initialization.
 * 
 * Updated: Adviser and Evaluation Date are now localized to each semester.
 */

import { ai } from '@/ai/genkit';
import { z } from 'zod';
import { 
  AutomatedProspectusCreationOutputSchema_Flat,
  type AutomatedProspectusCreationInput,
  type AutomatedProspectusCreationOutput
} from '@/ai/schemas/prospectus';

// --- Empty Template structure matching CSU years/semesters ---
const createEmptySemester = (name: string) => ({
  name,
  courses: [],
  programAdviserName: "",
  dateEvaluated: ""
});

const emptyCSUTemplate = {
  studentInfo: {
    name: "",
    id: "",
    permanentAddress: "",
    temporaryAddress: "",
    phone: "",
    yearAdmitted: ""
  },
  yearLevels: [
    { name: "FIRST YEAR", semesters: [createEmptySemester("First Semester"), createEmptySemester("Second Semester")] },
    { name: "SECOND YEAR", semesters: [createEmptySemester("First Semester"), createEmptySemester("Second Semester")] },
    { name: "THIRD YEAR", semesters: [createEmptySemester("First Semester"), createEmptySemester("Second Semester")] },
    { name: "FOURTH YEAR", semesters: [createEmptySemester("First Semester"), createEmptySemester("Second Semester")] }
  ],
  ojtSection: { hours: 300 },
  summaryOfUnits: { generalEducation: 0, professionalCourses: 0, majorCourses: 0, totalUnits: 0 }
};

/**
 * Robust wrapper for generating a blank prospectus record.
 * This function is optimized to ensure names are pre-populated from the enrollment input.
 */
export async function automatedProspectusCreation(
  input: AutomatedProspectusCreationInput
): Promise<AutomatedProspectusCreationOutput> {
  const currentYear = new Date().getFullYear().toString();
  
  // Format name: "LAST NAME, First Name" or fallback to provided name components
  let fullName = "";
  if (input.lastName || input.firstName) {
    const last = (input.lastName || "").trim().toUpperCase();
    const first = (input.firstName || "").trim();
    fullName = last && first ? `${last}, ${first}` : (last || first);
  }

  const blankData: AutomatedProspectusCreationOutput = {
    studentInfo: {
      name: fullName,
      id: input.studentId,
      permanentAddress: "",
      temporaryAddress: "",
      phone: "",
      yearAdmitted: currentYear
    },
    academicProspectus: JSON.parse(JSON.stringify(emptyCSUTemplate.yearLevels)) as any,
    ojtSection: emptyCSUTemplate.ojtSection,
    summaryOfUnits: emptyCSUTemplate.summaryOfUnits
  };

  return blankData;
}
