import { config } from 'dotenv';
config();

import '@/ai/flows/automated-prospectus-creation.ts';