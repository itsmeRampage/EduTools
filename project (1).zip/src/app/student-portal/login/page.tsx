"use client";

import { useState, useEffect, Suspense } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { GraduationCap, User, Loader2, ShieldCheck } from 'lucide-react';
import { useFirestore } from '@/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';

function LoginForm() {
  const router = useRouter();
  const { toast } = useToast();
  const db = useFirestore();
  
  const [studentId, setStudentId] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    sessionStorage.removeItem('student_portal_session');
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const tId = studentId.trim();
    const tPass = password.trim();

    if (!tId || !tPass) return;

    setIsLoading(true);
    try {
      const globalDocRef = doc(db, 'students', tId);
      const globalSnap = await getDoc(globalDocRef);

      if (globalSnap.exists()) {
        const globalData = globalSnap.data();
        const profId = globalData.managingProfessorId;
        
        // Custom logic: Default password is the Student ID if not set
        const correctPassword = globalData.portalPassword || tId;

        if (tPass !== correctPassword) {
          toast({
            variant: "destructive",
            title: "Access Denied",
            description: "Incorrect key. Try your Student ID if you haven't set a password yet.",
          });
          setIsLoading(false);
          return;
        }

        const studentDocRef = doc(db, 'professors', profId, 'students', tId);
        const studentSnap = await getDoc(studentDocRef);

        if (studentSnap.exists()) {
          const data = studentSnap.data();
          sessionStorage.setItem('student_portal_session', JSON.stringify({
            studentId: tId,
            profId,
            name: `${data.firstName || ''} ${data.lastName || ''}`.trim()
          }));
          router.push(`/student-portal/prospectus?prof=${profId}&sid=${tId}`);
        } else {
          toast({ variant: "destructive", title: "Record Error", description: "Official record is currently unavailable." });
          setIsLoading(false);
        }
      } else {
        toast({ variant: "destructive", title: "Not Found", description: "ID not found in the institutional registry." });
        setIsLoading(false);
      }
    } catch (err) {
      toast({ variant: "destructive", title: "Error", description: "Connection failure." });
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleLogin} className="space-y-4">
      <div className="space-y-2">
        <Label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Student ID</Label>
        <Input 
          placeholder="2024-XXXXX" 
          className="h-12 rounded-xl"
          value={studentId}
          onChange={(e) => setStudentId(e.target.value)}
          required 
          disabled={isLoading}
        />
      </div>
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Access Key</Label>
          <Link href="/student-portal/forgot-password" title="Recover" className="text-[10px] font-black text-primary uppercase tracking-widest hover:underline">
            Forgot Key?
          </Link>
        </div>
        <Input 
          type="password" 
          placeholder="••••••••"
          className="h-12 rounded-xl"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required 
          disabled={isLoading}
        />
      </div>
      <Button type="submit" className="w-full h-12 bg-primary font-black uppercase tracking-widest rounded-xl shadow-lg mt-4" disabled={isLoading}>
        {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <GraduationCap className="h-4 w-4 mr-2" />}
        Enter Portal
      </Button>
    </form>
  );
}

export default function StudentLoginPage() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-neutral-50 p-4">
      <Card className="w-full max-w-md shadow-2xl border-t-8 border-t-primary rounded-3xl overflow-hidden bg-white">
        <CardHeader className="space-y-1 text-center pb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-primary/5 p-4 rounded-full">
              <User className="h-10 w-10 text-primary" />
            </div>
          </div>
          <CardTitle className="text-3xl font-black text-secondary uppercase">Student Portal</CardTitle>
          <CardDescription className="font-medium">Access your official academic evaluation.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Suspense fallback={<Loader2 className="h-8 w-8 animate-spin mx-auto" />}>
            <LoginForm />
          </Suspense>
          <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-200 flex gap-3">
            <ShieldCheck className="h-4 w-4 text-primary mt-1" />
            <p className="text-[10px] text-neutral-500 font-medium">
              First-time users: Your **Student ID** is your initial Access Key. Please change it once logged in.
            </p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center bg-neutral-100/30 py-6">
          <p className="text-[10px] font-black text-neutral-400 uppercase tracking-widest">Institutional Grade Security • EDUProfile</p>
        </CardFooter>
      </Card>
    </div>
  );
}
