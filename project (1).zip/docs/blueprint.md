# **App Name**: EDUStudentProfilling

## Core Features:

- Professor Account Management: Secure sign-up, log-in, and profile management for professors, allowing them to access and manage student academic records.
- Course and Program Definition: Professors can add, edit, and define new courses/subjects and set up academic program structures (e.g., BS Computer Engineering curriculum), including required courses and credit units.
- Student Enrollment & Prospectus Setup Tool: Professors can enroll new students into specific academic programs. An AI tool automatically populates the student's academic prospectus layout with program-specific courses and placeholders, based on predefined curriculum structures, ensuring consistent initial setup.
- Academic Record & Grade Entry: A dashboard interface for viewing and updating student academic records semester by semester. Professors can input grades, course codes, and other relevant course details for each student.
- Automated Grade and GWA Computation: The system automatically computes remarks (PASSED/FAILED) based on entered grades and calculates both Semester General Weighted Average (GWA) and Overall GWA, updating these metrics in real-time.
- Academic Prospectus Generation & Export: Generate a digital version of the student's academic prospectus, including OJT sections and summary of units. This view can be exported as a printer-friendly format or a PDF document for official use.
- Backend Data Management: Robust data persistence layer supporting CRUD operations for professors, students, programs, courses, and prospectus records using a SQL-compliant database (e.g., MySQL or PostgreSQL).

## Style Guidelines:

- The visual design will be based on a light color scheme to emulate formal academic documents. The primary action color, used for buttons and key highlights, will be a subtle blue (#66A3CC), chosen to convey reliability and professionalism without being overly bold. The background will be an almost-white, heavily desaturated blue (#EEF3F7) derived from the primary hue, ensuring excellent readability. A deep, muted blue-green (#3D6666) will serve as an accent, providing distinct visual separation for elements like progress indicators or subheadings, while adhering to an overall sophisticated palette.
- Body and headline font: 'Inter' (sans-serif) for its neutral, objective, and highly readable characteristics, suitable for comprehensive academic data and print-friendly layouts. Course codes or similar technical data might optionally use a monospaced font if deemed necessary for clarity in specific contexts.
- Utilize minimalist and clean icons to complement the formal academic interface. Icons will primarily consist of solid, easily recognizable shapes for navigation, data entry, saving, printing, and other functional requirements, maintaining a consistent professional aesthetic.
- The layout will adopt a table-based structure, similar to official university forms and registrar evaluation sheets. Key sections such as student information, course tables grouped by year and semester, and summary panels will be clearly demarcated. The design will be mobile-responsive and optimized for printing to ensure functionality across various devices and output needs.
- Subtle, non-distracting animations will be implemented for enhanced user experience. These include gentle fade-in effects for content loading, smooth transitions for navigation between different academic years or semesters, and discrete hover states for interactive elements to provide visual feedback.