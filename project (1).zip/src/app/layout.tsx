import type {Metadata} from 'next';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { FirebaseClientProvider } from '@/firebase/client-provider';

export const metadata: Metadata = {
  title: 'EDUProfile | Institutional Academic Records & Student Portal',
  description: 'A professional student profiling system for faculty to manage academic prospectuses, evaluations, and class schedules. Features official evaluation printing and permanent student portals.',
  keywords: ['Academic Records', 'Student Evaluation', 'CSU Prospectus', 'Student Portal', 'Class Timetable', 'EDUProfile', 'Education Management'],
  viewport: 'width=device-width, initial-scale=1',
  robots: 'index, follow',
  openGraph: {
    title: 'EDUProfile | Academic Records Management',
    description: 'The standard for institutional academic evaluations and student profiling.',
    type: 'website',
  }
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased min-h-screen">
        <FirebaseClientProvider>
          {children}
          <Toaster />
        </FirebaseClientProvider>
      </body>
    </html>
  );
}
